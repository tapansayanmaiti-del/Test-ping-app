package com.example

import com.example.domain.engine.MetricsCalculator
import com.example.domain.model.NetworkQuality
import com.example.domain.model.NetworkThresholds
import com.example.domain.model.ProbeMethod
import com.example.domain.model.ProbeSample
import org.junit.Assert.assertEquals
import org.junit.Test

class MetricsCalculatorTest {

    private fun sample(id: Long, latency: Int?, success: Boolean = latency != null): ProbeSample =
        ProbeSample(
            id = id,
            timestampMs = id * 1000L,
            latencyMs = latency,
            jitterMs = 0,
            isSuccess = success,
            method = ProbeMethod.TCP_CONNECT,
            targetHost = "1.1.1.1:443"
        )

    @Test
    fun `jitter calculates mean consecutive absolute difference`() {
        val samples = listOf(
            sample(1, 20),
            sample(2, 30),
            sample(3, 24),
            sample(4, 34)
        )
        // diffs: |30-20|=10, |24-30|=6, |34-24|=10 -> avg = 26/3 = 8.67 -> 9
        assertEquals(9, MetricsCalculator.calculateJitterMs(samples))
    }

    @Test
    fun `packet loss computes accurate percentage`() {
        val samples = listOf(
            sample(1, 25, true),
            sample(2, null, false),
            sample(3, 28, true),
            sample(4, 30, true)
        )
        assertEquals(25.0f, MetricsCalculator.calculateWindowPacketLossPercent(samples), 0.01f)
    }

    @Test
    fun `evaluateQuality returns correct status tiers`() {
        val th = NetworkThresholds(excellentMaxMs = 40, goodMaxMs = 80, unstableMaxMs = 150)

        assertEquals(
            NetworkQuality.EXCELLENT,
            MetricsCalculator.evaluateQuality(true, 28, 4, 0f, th)
        )
        assertEquals(
            NetworkQuality.GOOD,
            MetricsCalculator.evaluateQuality(true, 62, 12, 0f, th)
        )
        assertEquals(
            NetworkQuality.UNSTABLE,
            MetricsCalculator.evaluateQuality(true, 110, 30, 1f, th)
        )
        assertEquals(
            NetworkQuality.POOR,
            MetricsCalculator.evaluateQuality(true, 220, 40, 15f, th)
        )
        assertEquals(
            NetworkQuality.OFFLINE,
            MetricsCalculator.evaluateQuality(false, null, 0, 100f, th)
        )
    }
}
