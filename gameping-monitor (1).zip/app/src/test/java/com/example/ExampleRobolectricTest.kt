package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun `read app name from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("GamePing Monitor", appName)
    }

    @Test
    fun `dashboard renders and navigates to overlay and graph tabs`() {
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("start_monitoring_button").assertIsDisplayed()
        composeRule.onNodeWithTag("nav_graph").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Real-Time Latency Graph").assertIsDisplayed()

        composeRule.onNodeWithTag("nav_overlay").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("LIVE OVERLAY PREVIEW").assertIsDisplayed()
    }
}
