package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.GamePingApplication
import com.example.MainActivity
import com.example.R
import com.example.domain.model.NetworkMetricsSnapshot
import com.example.overlay.FloatingOverlayManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class NetworkMonitorService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var notificationJob: Job? = null
    private var overlaySyncJob: Job? = null

    private lateinit var overlayManager: FloatingOverlayManager
    private var screenReceiverRegistered = false

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val controller = (application as GamePingApplication).monitorController
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> controller.setScreenOffPaused(true)
                Intent.ACTION_SCREEN_ON -> controller.setScreenOffPaused(false)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val app = application as GamePingApplication
        val controller = app.monitorController

        overlayManager = FloatingOverlayManager(
            context = this,
            controller = controller,
            onHideRequested = {
                serviceScope.launch {
                    controller.settingsRepository.setOverlayEnabled(false)
                }
                overlayManager.hide()
            }
        )

        registerScreenReceiver()
        observeOverlayAndNotifications()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val app = application as GamePingApplication
        val controller = app.monitorController

        ensureForeground(controller.metrics.value)

        when (intent?.action) {
            ACTION_START_MONITORING -> {
                controller.startMonitoring()
                if (controller.latestSettings.value.overlay.overlayEnabled && Settings.canDrawOverlays(this)) {
                    overlayManager.show()
                }
            }
            ACTION_STOP_SERVICE -> {
                controller.stopMonitoring()
                overlayManager.hide()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE_PAUSE -> {
                if (controller.metrics.value.isMonitoring) {
                    controller.togglePause()
                } else {
                    controller.startMonitoring()
                }
            }
            ACTION_SHOW_OVERLAY -> {
                serviceScope.launch {
                    controller.settingsRepository.setOverlayEnabled(true)
                }
                if (Settings.canDrawOverlays(this)) {
                    overlayManager.show()
                }
                if (!controller.metrics.value.isMonitoring) {
                    controller.startMonitoring()
                }
            }
            ACTION_HIDE_OVERLAY -> {
                serviceScope.launch {
                    controller.settingsRepository.setOverlayEnabled(false)
                }
                overlayManager.hide()
            }
            ACTION_TOGGLE_OVERLAY -> {
                val currentlyEnabled = controller.latestSettings.value.overlay.overlayEnabled
                val next = !currentlyEnabled
                serviceScope.launch {
                    controller.settingsRepository.setOverlayEnabled(next)
                }
                if (next && Settings.canDrawOverlays(this)) {
                    overlayManager.show()
                } else {
                    overlayManager.hide()
                }
            }
            ACTION_SYNC_OVERLAY -> {
                if (controller.latestSettings.value.overlay.overlayEnabled && Settings.canDrawOverlays(this)) {
                    overlayManager.show()
                } else {
                    overlayManager.hide()
                }
            }
        }

        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        if (screenReceiverRegistered) {
            try {
                unregisterReceiver(screenReceiver)
            } catch (_: Exception) {
            }
            screenReceiverRegistered = false
        }
        notificationJob?.cancel()
        overlaySyncJob?.cancel()
        overlayManager.hide()
        serviceScope.cancel()
    }

    private fun registerScreenReceiver() {
        if (screenReceiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        ContextCompat.registerReceiver(
            this,
            screenReceiver,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        screenReceiverRegistered = true
    }

    private fun observeOverlayAndNotifications() {
        val controller = (application as GamePingApplication).monitorController
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        notificationJob = serviceScope.launch {
            controller.metrics.collect { snapshot ->
                notificationManager.notify(NOTIFICATION_ID, buildNotification(snapshot))
            }
        }

        overlaySyncJob = serviceScope.launch {
            controller.settingsRepository.settingsFlow.collect { settings ->
                if (settings.overlay.overlayEnabled && Settings.canDrawOverlays(this@NetworkMonitorService)) {
                    if (!overlayManager.isShowing) {
                        overlayManager.show()
                    }
                } else if (overlayManager.isShowing) {
                    overlayManager.hide()
                }
            }
        }
    }

    private fun ensureForeground(snapshot: NetworkMetricsSnapshot) {
        val notification = buildNotification(snapshot)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(false)
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(snapshot: NetworkMetricsSnapshot): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val pauseActionIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, NetworkMonitorService::class.java).apply { action = ACTION_TOGGLE_PAUSE },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val overlayActionIntent = PendingIntent.getService(
            this,
            2,
            Intent(this, NetworkMonitorService::class.java).apply { action = ACTION_TOGGLE_OVERLAY },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopActionIntent = PendingIntent.getService(
            this,
            3,
            Intent(this, NetworkMonitorService::class.java).apply { action = ACTION_STOP_SERVICE },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val pingLabel = when {
            !snapshot.isMonitoring -> "Idle"
            snapshot.isPaused || snapshot.isScreenOffPaused -> "Paused"
            snapshot.livePingMs != null -> "${snapshot.livePingMs} ms"
            else -> "Measuring..."
        }

        val title = "Ping: $pingLabel • ${snapshot.quality.shortStatus} (${snapshot.activeMethod.shortBadge})"
        val subtitle =
            "Jitter: ${snapshot.jitterMs} ms • Loss: ${snapshot.packetLossPercent.roundToInt()}% • ${snapshot.connectivity.connectionType.shortLabel}"

        val overlayEnabled = (application as GamePingApplication)
            .monitorController.latestSettings.value.overlay.overlayEnabled

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(subtitle)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setContentIntent(contentPendingIntent)
            .addAction(0, if (snapshot.isPaused) "Resume" else "Pause", pauseActionIntent)
            .addAction(0, if (overlayEnabled) "Hide Overlay" else "Show Overlay", overlayActionIntent)
            .addAction(0, "Stop", stopActionIntent)
            .build()
    }

    companion object {
        private const val CHANNEL_ID = "network_monitor_channel"
        private const val NOTIFICATION_ID = 4042

        const val ACTION_START_MONITORING = "com.example.action.START_MONITORING"
        const val ACTION_STOP_SERVICE = "com.example.action.STOP_SERVICE"
        const val ACTION_TOGGLE_PAUSE = "com.example.action.TOGGLE_PAUSE"
        const val ACTION_SHOW_OVERLAY = "com.example.action.SHOW_OVERLAY"
        const val ACTION_HIDE_OVERLAY = "com.example.action.HIDE_OVERLAY"
        const val ACTION_TOGGLE_OVERLAY = "com.example.action.TOGGLE_OVERLAY"
        const val ACTION_SYNC_OVERLAY = "com.example.action.SYNC_OVERLAY"

        fun startMonitoring(context: Context) {
            sendAction(context, ACTION_START_MONITORING)
        }

        fun stopMonitoring(context: Context) {
            val intent = Intent(context, NetworkMonitorService::class.java).apply {
                action = ACTION_STOP_SERVICE
            }
            context.startService(intent)
        }

        fun showOverlay(context: Context) {
            sendAction(context, ACTION_SHOW_OVERLAY)
        }

        fun hideOverlay(context: Context) {
            val intent = Intent(context, NetworkMonitorService::class.java).apply {
                action = ACTION_HIDE_OVERLAY
            }
            context.startService(intent)
        }

        fun syncOverlayIfActive(context: Context) {
            sendAction(context, ACTION_SYNC_OVERLAY)
        }

        private fun sendAction(context: Context, actionName: String) {
            val intent = Intent(context, NetworkMonitorService::class.java).apply {
                action = actionName
            }
            ContextCompat.startForegroundService(context, intent)
        }
    }
}
