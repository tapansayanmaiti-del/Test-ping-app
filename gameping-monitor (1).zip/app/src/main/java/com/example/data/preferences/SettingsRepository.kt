package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.domain.model.NetworkThresholds
import com.example.domain.model.ProbeMethod
import com.example.domain.model.TestServerPreset
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "gameping_settings")

class SettingsRepository(private val context: Context) {

    private object Keys {
        val OVERLAY_ENABLED = booleanPreferencesKey("overlay_enabled")
        val THEME_PRESET = stringPreferencesKey("theme_preset")
        val CUSTOM_BG_COLOR = intPreferencesKey("custom_bg_color")
        val CUSTOM_TEXT_COLOR = intPreferencesKey("custom_text_color")
        val CUSTOM_ACCENT_COLOR = intPreferencesKey("custom_accent_color")
        val OVERLAY_ALPHA = floatPreferencesKey("overlay_alpha")
        val OVERLAY_SIZE = stringPreferencesKey("overlay_size")
        val FONT_SIZE_SP = floatPreferencesKey("font_size_sp")
        val EXPANDED_DEFAULT = booleanPreferencesKey("expanded_default")
        val POSITION_PRESET = stringPreferencesKey("position_preset")
        val SAVED_X = intPreferencesKey("saved_x")
        val SAVED_Y = intPreferencesKey("saved_y")
        val LOCK_TOUCH_THROUGH = booleanPreferencesKey("lock_touch_through")
        val SHOW_JITTER = booleanPreferencesKey("show_jitter")
        val SHOW_PACKET_LOSS = booleanPreferencesKey("show_packet_loss")
        val SHOW_AVG_MIN_MAX = booleanPreferencesKey("show_avg_min_max")
        val SHOW_CONNECTION_TYPE = booleanPreferencesKey("show_connection_type")
        val SHOW_PROBE_METHOD = booleanPreferencesKey("show_probe_method")

        val PROBE_INTERVAL_MS = longPreferencesKey("probe_interval_ms")
        val PROBE_METHOD = stringPreferencesKey("probe_method")
        val SERVER_PRESET = stringPreferencesKey("server_preset")
        val CUSTOM_HOST = stringPreferencesKey("custom_host")
        val CUSTOM_PORT = intPreferencesKey("custom_port")
        val CUSTOM_HTTPS_URL = stringPreferencesKey("custom_https_url")
        val PAUSE_SCREEN_OFF = booleanPreferencesKey("pause_screen_off")

        val EXCELLENT_MAX_MS = intPreferencesKey("excellent_max_ms")
        val GOOD_MAX_MS = intPreferencesKey("good_max_ms")
        val UNSTABLE_MAX_MS = intPreferencesKey("unstable_max_ms")
        val JITTER_WARN_MS = intPreferencesKey("jitter_warn_ms")
        val PACKET_LOSS_WARN = floatPreferencesKey("packet_loss_warn")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        val themePreset = prefs[Keys.THEME_PRESET]?.let { name ->
            OverlayThemePreset.entries.firstOrNull { it.name == name }
        } ?: OverlayThemePreset.DARK_GAMING

        val overlaySize = prefs[Keys.OVERLAY_SIZE]?.let { name ->
            OverlaySize.entries.firstOrNull { it.name == name }
        } ?: OverlaySize.MEDIUM

        val positionPreset = prefs[Keys.POSITION_PRESET]?.let { name ->
            OverlayPositionPreset.entries.firstOrNull { it.name == name }
        } ?: OverlayPositionPreset.TOP_RIGHT

        val probeMethod = prefs[Keys.PROBE_METHOD]?.let { name ->
            ProbeMethod.entries.firstOrNull { it.name == name }
        } ?: ProbeMethod.TCP_CONNECT

        val serverPreset = TestServerPreset.fromId(prefs[Keys.SERVER_PRESET] ?: "cloudflare")

        AppSettings(
            overlay = OverlaySettings(
                overlayEnabled = prefs[Keys.OVERLAY_ENABLED] ?: false,
                themePreset = themePreset,
                customBgColorArgb = prefs[Keys.CUSTOM_BG_COLOR] ?: 0xFF0A0F1D.toInt(),
                customTextColorArgb = prefs[Keys.CUSTOM_TEXT_COLOR] ?: 0xFFF3F7FF.toInt(),
                customAccentColorArgb = prefs[Keys.CUSTOM_ACCENT_COLOR] ?: 0xFF00E5FF.toInt(),
                alpha = prefs[Keys.OVERLAY_ALPHA] ?: 0.86f,
                size = overlaySize,
                fontSizeSp = prefs[Keys.FONT_SIZE_SP] ?: overlaySize.baseFontSp,
                expandedByDefault = prefs[Keys.EXPANDED_DEFAULT] ?: false,
                positionPreset = positionPreset,
                savedX = prefs[Keys.SAVED_X] ?: 24,
                savedY = prefs[Keys.SAVED_Y] ?: 120,
                lockTouchThrough = prefs[Keys.LOCK_TOUCH_THROUGH] ?: false,
                showJitter = prefs[Keys.SHOW_JITTER] ?: true,
                showPacketLoss = prefs[Keys.SHOW_PACKET_LOSS] ?: true,
                showAvgMinMax = prefs[Keys.SHOW_AVG_MIN_MAX] ?: true,
                showConnectionType = prefs[Keys.SHOW_CONNECTION_TYPE] ?: true,
                showProbeMethod = prefs[Keys.SHOW_PROBE_METHOD] ?: true
            ),
            monitoring = MonitoringSettings(
                probeIntervalMs = prefs[Keys.PROBE_INTERVAL_MS] ?: 1000L,
                probeMethod = probeMethod,
                serverPreset = serverPreset,
                customHost = prefs[Keys.CUSTOM_HOST] ?: "1.1.1.1",
                customPort = prefs[Keys.CUSTOM_PORT] ?: 443,
                customHttpsUrl = prefs[Keys.CUSTOM_HTTPS_URL] ?: "https://1.1.1.1/cdn-cgi/trace",
                pauseWhenScreenOff = prefs[Keys.PAUSE_SCREEN_OFF] ?: true,
                thresholds = NetworkThresholds(
                    excellentMaxMs = prefs[Keys.EXCELLENT_MAX_MS] ?: 40,
                    goodMaxMs = prefs[Keys.GOOD_MAX_MS] ?: 80,
                    unstableMaxMs = prefs[Keys.UNSTABLE_MAX_MS] ?: 150,
                    jitterWarningMs = prefs[Keys.JITTER_WARN_MS] ?: 25,
                    packetLossWarningPercent = prefs[Keys.PACKET_LOSS_WARN] ?: 2f
                )
            )
        )
    }

    suspend fun setOverlayEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.OVERLAY_ENABLED] = enabled }
    }

    suspend fun updateOverlaySettings(transform: (OverlaySettings) -> OverlaySettings) {
        context.dataStore.edit { prefs ->
            val current = OverlaySettings(
                overlayEnabled = prefs[Keys.OVERLAY_ENABLED] ?: false,
                themePreset = prefs[Keys.THEME_PRESET]?.let { n ->
                    OverlayThemePreset.entries.firstOrNull { it.name == n }
                } ?: OverlayThemePreset.DARK_GAMING,
                customBgColorArgb = prefs[Keys.CUSTOM_BG_COLOR] ?: 0xFF0A0F1D.toInt(),
                customTextColorArgb = prefs[Keys.CUSTOM_TEXT_COLOR] ?: 0xFFF3F7FF.toInt(),
                customAccentColorArgb = prefs[Keys.CUSTOM_ACCENT_COLOR] ?: 0xFF00E5FF.toInt(),
                alpha = prefs[Keys.OVERLAY_ALPHA] ?: 0.86f,
                size = prefs[Keys.OVERLAY_SIZE]?.let { n ->
                    OverlaySize.entries.firstOrNull { it.name == n }
                } ?: OverlaySize.MEDIUM,
                fontSizeSp = prefs[Keys.FONT_SIZE_SP] ?: 12.5f,
                expandedByDefault = prefs[Keys.EXPANDED_DEFAULT] ?: false,
                positionPreset = prefs[Keys.POSITION_PRESET]?.let { n ->
                    OverlayPositionPreset.entries.firstOrNull { it.name == n }
                } ?: OverlayPositionPreset.TOP_RIGHT,
                savedX = prefs[Keys.SAVED_X] ?: 24,
                savedY = prefs[Keys.SAVED_Y] ?: 120,
                lockTouchThrough = prefs[Keys.LOCK_TOUCH_THROUGH] ?: false,
                showJitter = prefs[Keys.SHOW_JITTER] ?: true,
                showPacketLoss = prefs[Keys.SHOW_PACKET_LOSS] ?: true,
                showAvgMinMax = prefs[Keys.SHOW_AVG_MIN_MAX] ?: true,
                showConnectionType = prefs[Keys.SHOW_CONNECTION_TYPE] ?: true,
                showProbeMethod = prefs[Keys.SHOW_PROBE_METHOD] ?: true
            )
            val updated = transform(current)
            prefs[Keys.OVERLAY_ENABLED] = updated.overlayEnabled
            prefs[Keys.THEME_PRESET] = updated.themePreset.name
            prefs[Keys.CUSTOM_BG_COLOR] = updated.customBgColorArgb
            prefs[Keys.CUSTOM_TEXT_COLOR] = updated.customTextColorArgb
            prefs[Keys.CUSTOM_ACCENT_COLOR] = updated.customAccentColorArgb
            prefs[Keys.OVERLAY_ALPHA] = updated.alpha.coerceIn(0.30f, 1.0f)
            prefs[Keys.OVERLAY_SIZE] = updated.size.name
            prefs[Keys.FONT_SIZE_SP] = updated.fontSizeSp.coerceIn(9f, 20f)
            prefs[Keys.EXPANDED_DEFAULT] = updated.expandedByDefault
            prefs[Keys.POSITION_PRESET] = updated.positionPreset.name
            prefs[Keys.SAVED_X] = updated.savedX
            prefs[Keys.SAVED_Y] = updated.savedY
            prefs[Keys.LOCK_TOUCH_THROUGH] = updated.lockTouchThrough
            prefs[Keys.SHOW_JITTER] = updated.showJitter
            prefs[Keys.SHOW_PACKET_LOSS] = updated.showPacketLoss
            prefs[Keys.SHOW_AVG_MIN_MAX] = updated.showAvgMinMax
            prefs[Keys.SHOW_CONNECTION_TYPE] = updated.showConnectionType
            prefs[Keys.SHOW_PROBE_METHOD] = updated.showProbeMethod
        }
    }

    suspend fun saveOverlayCoordinates(x: Int, y: Int) {
        context.dataStore.edit {
            it[Keys.SAVED_X] = x
            it[Keys.SAVED_Y] = y
            it[Keys.POSITION_PRESET] = OverlayPositionPreset.CUSTOM.name
        }
    }

    suspend fun updateMonitoringSettings(transform: (MonitoringSettings) -> MonitoringSettings) {
        context.dataStore.edit { prefs ->
            val current = MonitoringSettings(
                probeIntervalMs = prefs[Keys.PROBE_INTERVAL_MS] ?: 1000L,
                probeMethod = prefs[Keys.PROBE_METHOD]?.let { n ->
                    ProbeMethod.entries.firstOrNull { it.name == n }
                } ?: ProbeMethod.TCP_CONNECT,
                serverPreset = TestServerPreset.fromId(prefs[Keys.SERVER_PRESET] ?: "cloudflare"),
                customHost = prefs[Keys.CUSTOM_HOST] ?: "1.1.1.1",
                customPort = prefs[Keys.CUSTOM_PORT] ?: 443,
                customHttpsUrl = prefs[Keys.CUSTOM_HTTPS_URL] ?: "https://1.1.1.1/cdn-cgi/trace",
                pauseWhenScreenOff = prefs[Keys.PAUSE_SCREEN_OFF] ?: true,
                thresholds = NetworkThresholds(
                    excellentMaxMs = prefs[Keys.EXCELLENT_MAX_MS] ?: 40,
                    goodMaxMs = prefs[Keys.GOOD_MAX_MS] ?: 80,
                    unstableMaxMs = prefs[Keys.UNSTABLE_MAX_MS] ?: 150,
                    jitterWarningMs = prefs[Keys.JITTER_WARN_MS] ?: 25,
                    packetLossWarningPercent = prefs[Keys.PACKET_LOSS_WARN] ?: 2f
                )
            )
            val updated = transform(current)
            prefs[Keys.PROBE_INTERVAL_MS] = updated.probeIntervalMs.coerceIn(300L, 10000L)
            prefs[Keys.PROBE_METHOD] = updated.probeMethod.name
            prefs[Keys.SERVER_PRESET] = updated.serverPreset.id
            prefs[Keys.CUSTOM_HOST] = updated.customHost
            prefs[Keys.CUSTOM_PORT] = updated.customPort.coerceIn(1, 65535)
            prefs[Keys.CUSTOM_HTTPS_URL] = updated.customHttpsUrl
            prefs[Keys.PAUSE_SCREEN_OFF] = updated.pauseWhenScreenOff
            prefs[Keys.EXCELLENT_MAX_MS] = updated.thresholds.excellentMaxMs
            prefs[Keys.GOOD_MAX_MS] = updated.thresholds.goodMaxMs
            prefs[Keys.UNSTABLE_MAX_MS] = updated.thresholds.unstableMaxMs
            prefs[Keys.JITTER_WARN_MS] = updated.thresholds.jitterWarningMs
            prefs[Keys.PACKET_LOSS_WARN] = updated.thresholds.packetLossWarningPercent
        }
    }
}
