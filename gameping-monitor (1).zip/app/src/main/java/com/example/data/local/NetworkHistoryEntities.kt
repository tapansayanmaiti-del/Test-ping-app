package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "network_sessions")
data class NetworkSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val startTimeMs: Long,
    val endTimeMs: Long,
    val durationSec: Long,
    val targetHost: String,
    val probeMethod: String,
    val connectionType: String,
    val avgPingMs: Int,
    val minPingMs: Int,
    val maxPingMs: Int,
    val avgJitterMs: Int,
    val packetLossPercent: Float,
    val totalProbes: Int,
    val failedProbes: Int,
    val interruptionsCount: Int,
    val qualityLabel: String
)

@Entity(tableName = "network_events")
data class NetworkEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val timestampMs: Long,
    val eventType: String,
    val title: String,
    val detail: String
)
