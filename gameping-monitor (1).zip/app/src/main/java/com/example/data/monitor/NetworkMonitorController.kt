package com.example.data.monitor

import android.content.Context
import com.example.data.local.NetworkEventEntity
import com.example.data.local.NetworkHistoryRepository
import com.example.data.local.NetworkSessionEntity
import com.example.data.preferences.AppSettings
import com.example.data.preferences.SettingsRepository
import com.example.domain.engine.ConnectivityObserver
import com.example.domain.engine.MetricsCalculator
import com.example.domain.engine.NetworkProbeClient
import com.example.domain.model.LiveEventType
import com.example.domain.model.LiveNetworkEvent
import com.example.domain.model.NetworkMetricsSnapshot
import com.example.domain.model.NetworkQuality
import com.example.domain.model.ProbeMethod
import com.example.domain.model.ProbeSample
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.roundToInt

class NetworkMonitorController(
    context: Context,
    val settingsRepository: SettingsRepository,
    val historyRepository: NetworkHistoryRepository
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val probeClient = NetworkProbeClient()
    val connectivityObserver = ConnectivityObserver(context.applicationContext)

    private val _metrics = MutableStateFlow(NetworkMetricsSnapshot())
    val metrics: StateFlow<NetworkMetricsSnapshot> = _metrics.asStateFlow()

    private val _latestSettings = MutableStateFlow(AppSettings())
    val latestSettings: StateFlow<AppSettings> = _latestSettings.asStateFlow()

    private var monitorJob: Job? = null
    private var timerJob: Job? = null

    private var currentSessionId: Long? = null
    private var sessionStartTimeMs: Long = 0L
    private var totalProbes = 0
    private var failedProbes = 0
    private var sumSuccessPing = 0L
    private var successCount = 0
    private var minPing = Int.MAX_VALUE
    private var maxPing = 0
    private var lastSuccessPing: Int? = null
    private var interruptionsCount = 0
    private var lastInterruptionStartMs: Long? = null
    private var lastSpikeEventMs: Long = 0L
    private val eventIdCounter = AtomicLong(1L)

    private var wasConnected: Boolean? = null

    init {
        connectivityObserver.startObserving()

        scope.launch {
            settingsRepository.settingsFlow.collect { settings ->
                _latestSettings.value = settings
                _metrics.update { current ->
                    val target = when (settings.monitoring.probeMethod) {
                        ProbeMethod.TCP_CONNECT ->
                            "${settings.monitoring.resolvedHost()}:${settings.monitoring.resolvedPort()}"
                        ProbeMethod.ICMP_ECHO -> settings.monitoring.resolvedHost()
                        ProbeMethod.HTTPS_RESPONSE ->
                            settings.monitoring.resolvedHttpsUrl().removePrefix("https://").substringBefore("/")
                        ProbeMethod.DNS_LOOKUP -> settings.monitoring.resolvedDnsHost()
                    }
                    current.copy(
                        activeMethod = settings.monitoring.probeMethod,
                        targetDisplay = target
                    )
                }
            }
        }

        scope.launch {
            connectivityObserver.state.collect { conn ->
                val prev = wasConnected
                wasConnected = conn.isConnected

                _metrics.update { current ->
                    val quality = if (!conn.isConnected) {
                        NetworkQuality.OFFLINE
                    } else if (current.totalProbes > 0) {
                        MetricsCalculator.evaluateQuality(
                            isConnected = true,
                            livePingMs = current.livePingMs,
                            jitterMs = current.jitterMs,
                            packetLossPercent = current.packetLossPercent,
                            thresholds = _latestSettings.value.monitoring.thresholds
                        )
                    } else {
                        NetworkQuality.GOOD
                    }
                    current.copy(
                        connectivity = conn,
                        quality = quality
                    )
                }

                if (prev == true && !conn.isConnected) {
                    onConnectionInterrupted()
                } else if (prev == false && conn.isConnected) {
                    onConnectionRecovered(conn.transportDetail)
                }
            }
        }
    }

    fun startMonitoring() {
        if (monitorJob?.isActive == true) {
            if (_metrics.value.isPaused) {
                resumeMonitoring()
            }
            return
        }

        resetSessionCounters()
        sessionStartTimeMs = System.currentTimeMillis()
        val settings = _latestSettings.value.monitoring
        val conn = connectivityObserver.state.value

        _metrics.update {
            it.copy(
                isMonitoring = true,
                isPaused = false,
                isScreenOffPaused = false,
                sessionDurationSec = 0L,
                recentSamples = emptyList(),
                recentEvents = emptyList(),
                totalProbes = 0,
                failedProbes = 0,
                avgPingMs = 0,
                minPingMs = 0,
                maxPingMs = 0,
                jitterMs = 0,
                packetLossPercent = 0f,
                livePingMs = null,
                lastError = null,
                quality = if (conn.isConnected) NetworkQuality.GOOD else NetworkQuality.OFFLINE
            )
        }

        scope.launch {
            val session = NetworkSessionEntity(
                startTimeMs = sessionStartTimeMs,
                endTimeMs = sessionStartTimeMs,
                durationSec = 0L,
                targetHost = _metrics.value.targetDisplay,
                probeMethod = settings.probeMethod.displayName,
                connectionType = conn.connectionType.displayName,
                avgPingMs = 0,
                minPingMs = 0,
                maxPingMs = 0,
                avgJitterMs = 0,
                packetLossPercent = 0f,
                totalProbes = 0,
                failedProbes = 0,
                interruptionsCount = 0,
                qualityLabel = _metrics.value.quality.label
            )
            currentSessionId = historyRepository.createSession(session)
            recordEvent(
                type = LiveEventType.SESSION_STARTED,
                title = "Monitoring Started",
                detail = "${settings.probeMethod.displayName} → ${_metrics.value.targetDisplay}"
            )
        }

        timerJob?.cancel()
        timerJob = scope.launch {
            while (isActive) {
                delay(1000L)
                val snap = _metrics.value
                if (snap.isMonitoring && !snap.isPaused && !snap.isScreenOffPaused) {
                    val elapsed = ((System.currentTimeMillis() - sessionStartTimeMs) / 1000L).coerceAtLeast(0L)
                    _metrics.update { it.copy(sessionDurationSec = elapsed) }
                    if (elapsed > 0 && elapsed % 10L == 0L) {
                        persistCurrentSessionSnapshot()
                    }
                }
            }
        }

        monitorJob = scope.launch {
            var probeCycle = 0
            while (isActive) {
                val currentMetrics = _metrics.value
                if (currentMetrics.isPaused || currentMetrics.isScreenOffPaused) {
                    delay(250L)
                    continue
                }

                val monSettings = _latestSettings.value.monitoring
                val connState = connectivityObserver.state.value

                if (!connState.isConnected) {
                    val offlineSample = ProbeSample(
                        id = System.nanoTime(),
                        timestampMs = System.currentTimeMillis(),
                        latencyMs = null,
                        jitterMs = 0,
                        isSuccess = false,
                        method = monSettings.probeMethod,
                        targetHost = _metrics.value.targetDisplay,
                        errorMessage = "No active internet connection"
                    )
                    handleProbeSample(offlineSample, isOffline = true)
                    delay(monSettings.probeIntervalMs)
                    continue
                }

                val sample = probeClient.measure(
                    method = monSettings.probeMethod,
                    host = monSettings.resolvedHost(),
                    port = monSettings.resolvedPort(),
                    httpsUrl = monSettings.resolvedHttpsUrl(),
                    dnsHost = monSettings.resolvedDnsHost()
                )

                // Periodically refresh DNS latency reference when using non-DNS probe
                var dnsLatency: Int? = _metrics.value.lastDnsMs
                if (monSettings.probeMethod == ProbeMethod.DNS_LOOKUP) {
                    dnsLatency = sample.latencyMs
                } else if (probeCycle % 10 == 0) {
                    val dnsSample = probeClient.measureDnsLookup(monSettings.resolvedDnsHost())
                    if (dnsSample.isSuccess) {
                        dnsLatency = dnsSample.latencyMs
                    }
                }
                probeCycle++

                handleProbeSample(sample, isOffline = false, dnsLatencyMs = dnsLatency)
                delay(monSettings.probeIntervalMs)
            }
        }
    }

    fun stopMonitoring() {
        monitorJob?.cancel()
        monitorJob = null
        timerJob?.cancel()
        timerJob = null

        val snap = _metrics.value
        if (snap.isMonitoring) {
            scope.launch {
                persistCurrentSessionSnapshot(finalEndMs = System.currentTimeMillis())
                currentSessionId = null
            }
        }

        _metrics.update {
            it.copy(
                isMonitoring = false,
                isPaused = false,
                isScreenOffPaused = false
            )
        }
    }

    fun togglePause() {
        if (!_metrics.value.isMonitoring) return
        _metrics.update { it.copy(isPaused = !it.isPaused) }
    }

    fun resumeMonitoring() {
        if (!_metrics.value.isMonitoring) return
        _metrics.update { it.copy(isPaused = false, isScreenOffPaused = false) }
    }

    fun setScreenOffPaused(paused: Boolean) {
        if (!_metrics.value.isMonitoring) return
        if (paused && !_latestSettings.value.monitoring.pauseWhenScreenOff) return
        _metrics.update { it.copy(isScreenOffPaused = paused) }
    }

    suspend fun runSingleDiagnostic(method: ProbeMethod): ProbeSample {
        val mon = _latestSettings.value.monitoring
        return probeClient.measure(
            method = method,
            host = mon.resolvedHost(),
            port = mon.resolvedPort(),
            httpsUrl = mon.resolvedHttpsUrl(),
            dnsHost = mon.resolvedDnsHost()
        )
    }

    private fun handleProbeSample(
        rawSample: ProbeSample,
        isOffline: Boolean,
        dnsLatencyMs: Int? = _metrics.value.lastDnsMs
    ) {
        totalProbes++
        if (!rawSample.isSuccess) {
            failedProbes++
        }

        val instantJitter = if (rawSample.isSuccess && rawSample.latencyMs != null) {
            val j = MetricsCalculator.calculateInstantJitter(lastSuccessPing, rawSample.latencyMs)
            lastSuccessPing = rawSample.latencyMs
            sumSuccessPing += rawSample.latencyMs
            successCount++
            if (rawSample.latencyMs < minPing) minPing = rawSample.latencyMs
            if (rawSample.latencyMs > maxPing) maxPing = rawSample.latencyMs
            j
        } else {
            0
        }

        val sample = rawSample.copy(jitterMs = instantJitter)
        val thresholds = _latestSettings.value.monitoring.thresholds

        _metrics.update { current ->
            val updatedSamples = (current.recentSamples + sample).takeLast(60)
            val rollingJitter = MetricsCalculator.calculateJitterMs(updatedSamples.takeLast(20))
            val lossPercent = MetricsCalculator.calculateWindowPacketLossPercent(updatedSamples, 30)
            val avgPing = if (successCount > 0) (sumSuccessPing.toDouble() / successCount).roundToInt() else 0
            val conn = current.connectivity

            val quality = MetricsCalculator.evaluateQuality(
                isConnected = conn.isConnected && !isOffline,
                livePingMs = sample.latencyMs,
                jitterMs = rollingJitter,
                packetLossPercent = lossPercent,
                thresholds = thresholds
            )

            current.copy(
                livePingMs = sample.latencyMs,
                avgPingMs = avgPing,
                minPingMs = if (minPing == Int.MAX_VALUE) 0 else minPing,
                maxPingMs = maxPing,
                jitterMs = rollingJitter,
                packetLossPercent = lossPercent,
                quality = quality,
                totalProbes = totalProbes,
                failedProbes = failedProbes,
                lastDnsMs = dnsLatencyMs ?: sample.breakdown?.dnsMs?.roundToInt(),
                lastError = if (sample.isSuccess) null else sample.errorMessage,
                recentSamples = updatedSamples
            )
        }

        if (sample.isSuccess && sample.latencyMs != null && sample.latencyMs > thresholds.unstableMaxMs) {
            val now = System.currentTimeMillis()
            if (now - lastSpikeEventMs > 10_000L) {
                lastSpikeEventMs = now
                recordEvent(
                    type = LiveEventType.HIGH_LATENCY_SPIKE,
                    title = "Latency Spike (${sample.latencyMs} ms)",
                    detail = "${sample.method.shortBadge} probe exceeded ${thresholds.unstableMaxMs} ms threshold"
                )
            }
        }
    }

    private fun onConnectionInterrupted() {
        interruptionsCount++
        lastInterruptionStartMs = System.currentTimeMillis()
        if (_metrics.value.isMonitoring) {
            recordEvent(
                type = LiveEventType.INTERRUPTION,
                title = "Connection Lost",
                detail = "Active network interface dropped"
            )
        }
    }

    private fun onConnectionRecovered(detail: String) {
        val downtimeMs = lastInterruptionStartMs?.let { System.currentTimeMillis() - it }
        lastInterruptionStartMs = null
        if (_metrics.value.isMonitoring) {
            val sec = downtimeMs?.let { String.format("%.1fs", it / 1000.0) } ?: "brief"
            recordEvent(
                type = LiveEventType.RECOVERY,
                title = "Connection Restored",
                detail = "Back online via $detail (downtime: $sec)"
            )
        }
    }

    private fun recordEvent(type: LiveEventType, title: String, detail: String) {
        val now = System.currentTimeMillis()
        val event = LiveNetworkEvent(
            id = eventIdCounter.getAndIncrement(),
            timestampMs = now,
            type = type,
            title = title,
            detail = detail
        )
        _metrics.update { current ->
            current.copy(recentEvents = (listOf(event) + current.recentEvents).take(40))
        }
        val sessionId = currentSessionId ?: return
        scope.launch {
            historyRepository.logEvent(
                NetworkEventEntity(
                    sessionId = sessionId,
                    timestampMs = now,
                    eventType = type.name,
                    title = title,
                    detail = detail
                )
            )
        }
    }

    private suspend fun persistCurrentSessionSnapshot(finalEndMs: Long? = null) {
        val sessionId = currentSessionId ?: return
        val snap = _metrics.value
        val endMs = finalEndMs ?: System.currentTimeMillis()
        val duration = ((endMs - sessionStartTimeMs) / 1000L).coerceAtLeast(snap.sessionDurationSec)
        val totalLoss = MetricsCalculator.calculatePacketLossPercent(totalProbes, failedProbes)
        val entity = NetworkSessionEntity(
            id = sessionId,
            startTimeMs = sessionStartTimeMs,
            endTimeMs = endMs,
            durationSec = duration,
            targetHost = snap.targetDisplay,
            probeMethod = snap.activeMethod.displayName,
            connectionType = snap.connectivity.connectionType.displayName,
            avgPingMs = snap.avgPingMs,
            minPingMs = snap.minPingMs,
            maxPingMs = snap.maxPingMs,
            avgJitterMs = snap.jitterMs,
            packetLossPercent = totalLoss,
            totalProbes = totalProbes,
            failedProbes = failedProbes,
            interruptionsCount = interruptionsCount,
            qualityLabel = snap.quality.label
        )
        historyRepository.updateSession(entity)
    }

    private fun resetSessionCounters() {
        totalProbes = 0
        failedProbes = 0
        sumSuccessPing = 0L
        successCount = 0
        minPing = Int.MAX_VALUE
        maxPing = 0
        lastSuccessPing = null
        interruptionsCount = 0
        lastInterruptionStartMs = null
        lastSpikeEventMs = 0L
    }
}
