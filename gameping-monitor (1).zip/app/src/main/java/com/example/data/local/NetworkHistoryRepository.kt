package com.example.data.local

import kotlinx.coroutines.flow.Flow

class NetworkHistoryRepository(private val dao: NetworkHistoryDao) {

    val allSessions: Flow<List<NetworkSessionEntity>> = dao.observeAllSessions()
    val recentEvents: Flow<List<NetworkEventEntity>> = dao.observeRecentEvents()

    fun observeEventsForSession(sessionId: Long): Flow<List<NetworkEventEntity>> =
        dao.observeEventsForSession(sessionId)

    suspend fun createSession(session: NetworkSessionEntity): Long =
        dao.insertSession(session)

    suspend fun updateSession(session: NetworkSessionEntity) =
        dao.updateSession(session)

    suspend fun logEvent(event: NetworkEventEntity): Long =
        dao.insertEvent(event)

    suspend fun deleteSession(sessionId: Long) {
        dao.deleteEventsForSession(sessionId)
        dao.deleteSession(sessionId)
    }

    suspend fun clearAll() {
        dao.clearAllEvents()
        dao.clearAllSessions()
    }
}
