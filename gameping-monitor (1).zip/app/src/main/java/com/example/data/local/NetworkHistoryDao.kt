package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface NetworkHistoryDao {

    @Query("SELECT * FROM network_sessions ORDER BY startTimeMs DESC")
    fun observeAllSessions(): Flow<List<NetworkSessionEntity>>

    @Query("SELECT * FROM network_events ORDER BY timestampMs DESC LIMIT 200")
    fun observeRecentEvents(): Flow<List<NetworkEventEntity>>

    @Query("SELECT * FROM network_events WHERE sessionId = :sessionId ORDER BY timestampMs DESC")
    fun observeEventsForSession(sessionId: Long): Flow<List<NetworkEventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: NetworkSessionEntity): Long

    @Update
    suspend fun updateSession(session: NetworkSessionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(event: NetworkEventEntity): Long

    @Query("DELETE FROM network_sessions WHERE id = :sessionId")
    suspend fun deleteSession(sessionId: Long)

    @Query("DELETE FROM network_events WHERE sessionId = :sessionId")
    suspend fun deleteEventsForSession(sessionId: Long)

    @Query("DELETE FROM network_sessions")
    suspend fun clearAllSessions()

    @Query("DELETE FROM network_events")
    suspend fun clearAllEvents()
}
