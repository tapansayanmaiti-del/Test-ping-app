package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [NetworkSessionEntity::class, NetworkEventEntity::class],
    version = 1,
    exportSchema = false
)
abstract class GamePingDatabase : RoomDatabase() {
    abstract fun networkHistoryDao(): NetworkHistoryDao

    companion object {
        @Volatile
        private var INSTANCE: GamePingDatabase? = null

        fun getInstance(context: Context): GamePingDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    GamePingDatabase::class.java,
                    "gameping_history.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
