package com.example.data.preferences

import com.example.domain.model.NetworkThresholds
import com.example.domain.model.ProbeMethod
import com.example.domain.model.TestServerPreset

enum class OverlayThemePreset(
    val displayName: String,
    val backgroundArgb: Int,
    val borderArgb: Int,
    val textArgb: Int,
    val accentArgb: Int
) {
    DARK_GAMING(
        displayName = "Dark Gaming",
        backgroundArgb = 0xFF0A0F1D.toInt(),
        borderArgb = 0xFF1F2D4A.toInt(),
        textArgb = 0xFFF3F7FF.toInt(),
        accentArgb = 0xFF00FF9D.toInt()
    ),
    NEON_BLUE(
        displayName = "Neon Blue",
        backgroundArgb = 0xFF041428.toInt(),
        borderArgb = 0xFF00E5FF.toInt(),
        textArgb = 0xFFE6FBFF.toInt(),
        accentArgb = 0xFF00E5FF.toInt()
    ),
    CYBER_PURPLE(
        displayName = "Cyber Purple",
        backgroundArgb = 0xFF170B2B.toInt(),
        borderArgb = 0xFFA855F7.toInt(),
        textArgb = 0xFFF5EEFF.toInt(),
        accentArgb = 0xFFC084FC.toInt()
    ),
    MINIMAL_BLACK(
        displayName = "Minimal Black",
        backgroundArgb = 0xFF000000.toInt(),
        borderArgb = 0xFF333333.toInt(),
        textArgb = 0xFFFFFFFF.toInt(),
        accentArgb = 0xFF38BDF8.toInt()
    ),
    CUSTOM(
        displayName = "Custom",
        backgroundArgb = 0xFF0B1120.toInt(),
        borderArgb = 0xFF38BDF8.toInt(),
        textArgb = 0xFFFFFFFF.toInt(),
        accentArgb = 0xFF00FF9D.toInt()
    )
}

enum class OverlaySize(val label: String, val scale: Float, val baseFontSp: Float) {
    COMPACT("Small", 0.88f, 11f),
    MEDIUM("Medium", 1.0f, 12.5f),
    LARGE("Large", 1.18f, 14.5f)
}

enum class OverlayPositionPreset(val label: String) {
    TOP_LEFT("Top Left"),
    TOP_RIGHT("Top Right"),
    BOTTOM_LEFT("Bottom Left"),
    BOTTOM_RIGHT("Bottom Right"),
    CUSTOM("Custom Drag")
}

data class OverlaySettings(
    val overlayEnabled: Boolean = false,
    val themePreset: OverlayThemePreset = OverlayThemePreset.DARK_GAMING,
    val customBgColorArgb: Int = 0xFF0A0F1D.toInt(),
    val customTextColorArgb: Int = 0xFFF3F7FF.toInt(),
    val customAccentColorArgb: Int = 0xFF00E5FF.toInt(),
    val alpha: Float = 0.86f,
    val size: OverlaySize = OverlaySize.MEDIUM,
    val fontSizeSp: Float = 12.5f,
    val expandedByDefault: Boolean = false,
    val positionPreset: OverlayPositionPreset = OverlayPositionPreset.TOP_RIGHT,
    val savedX: Int = 24,
    val savedY: Int = 120,
    val lockTouchThrough: Boolean = false,
    val showJitter: Boolean = true,
    val showPacketLoss: Boolean = true,
    val showAvgMinMax: Boolean = true,
    val showConnectionType: Boolean = true,
    val showProbeMethod: Boolean = true
) {
    fun effectiveBgColor(): Int =
        if (themePreset == OverlayThemePreset.CUSTOM) customBgColorArgb else themePreset.backgroundArgb

    fun effectiveTextColor(): Int =
        if (themePreset == OverlayThemePreset.CUSTOM) customTextColorArgb else themePreset.textArgb

    fun effectiveBorderColor(): Int =
        if (themePreset == OverlayThemePreset.CUSTOM) customAccentColorArgb else themePreset.borderArgb

    fun effectiveAccentColor(): Int =
        if (themePreset == OverlayThemePreset.CUSTOM) customAccentColorArgb else themePreset.accentArgb
}

data class MonitoringSettings(
    val probeIntervalMs: Long = 1000L,
    val probeMethod: ProbeMethod = ProbeMethod.TCP_CONNECT,
    val serverPreset: TestServerPreset = TestServerPreset.CLOUDFLARE,
    val customHost: String = "1.1.1.1",
    val customPort: Int = 443,
    val customHttpsUrl: String = "https://1.1.1.1/cdn-cgi/trace",
    val pauseWhenScreenOff: Boolean = true,
    val thresholds: NetworkThresholds = NetworkThresholds()
) {
    fun resolvedHost(): String =
        if (serverPreset == TestServerPreset.CUSTOM) customHost.ifBlank { "1.1.1.1" } else serverPreset.host

    fun resolvedPort(): Int =
        if (serverPreset == TestServerPreset.CUSTOM) customPort.coerceIn(1, 65535) else serverPreset.port

    fun resolvedHttpsUrl(): String =
        if (serverPreset == TestServerPreset.CUSTOM) {
            customHttpsUrl.ifBlank { "https://${resolvedHost()}" }
        } else {
            serverPreset.httpsUrl
        }

    fun resolvedDnsHost(): String =
        if (serverPreset == TestServerPreset.CUSTOM) resolvedHost() else serverPreset.dnsHost
}

data class AppSettings(
    val overlay: OverlaySettings = OverlaySettings(),
    val monitoring: MonitoringSettings = MonitoringSettings()
)
