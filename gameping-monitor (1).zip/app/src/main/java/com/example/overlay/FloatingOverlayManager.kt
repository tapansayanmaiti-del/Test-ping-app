package com.example.overlay

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.res.ResourcesCompat
import com.example.MainActivity
import com.example.R
import com.example.data.monitor.NetworkMonitorController
import com.example.data.preferences.OverlayPositionPreset
import com.example.data.preferences.OverlaySettings
import com.example.domain.model.NetworkMetricsSnapshot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

class FloatingOverlayManager(
    private val context: Context,
    private val controller: NetworkMonitorController,
    private val onHideRequested: () -> Unit
) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var scope: CoroutineScope? = null
    private var collectJob: Job? = null

    private var rootContainer: LinearLayout? = null
    private var layoutParams: WindowManager.LayoutParams? = null
    private var isExpanded = false
    private var lastAppliedPreset: OverlayPositionPreset? = null

    // UI references
    private var statusDot: View? = null
    private var pingText: TextView? = null
    private var methodBadge: TextView? = null
    private var compactMetaText: TextView? = null
    private var expandChevron: TextView? = null

    private var expandedSection: LinearLayout? = null
    private var statusLabelText: TextView? = null
    private var avgMinMaxText: TextView? = null
    private var jitterLossText: TextView? = null
    private var connectionText: TextView? = null
    private var pauseButton: TextView? = null
    private var openAppButton: TextView? = null
    private var hideButton: TextView? = null

    private val monoTypeface: Typeface? by lazy {
        ResourcesCompat.getFont(context, R.font.jetbrains_mono) ?: Typeface.MONOSPACE
    }
    private val headingTypeface: Typeface? by lazy {
        ResourcesCompat.getFont(context, R.font.space_grotesk) ?: Typeface.SANS_SERIF
    }

    val isShowing: Boolean
        get() = rootContainer != null

    @SuppressLint("ClickableViewAccessibility")
    fun show() {
        if (!Settings.canDrawOverlays(context)) return
        if (rootContainer != null) return

        val initialSettings = controller.latestSettings.value.overlay
        isExpanded = initialSettings.expandedByDefault
        lastAppliedPreset = initialSettings.positionPreset

        val view = buildOverlayView()
        val params = createLayoutParams(initialSettings)

        try {
            windowManager.addView(view, params)
            rootContainer = view
            layoutParams = params
            attachDragListener(view, params)
            startCollectingState()
        } catch (_: Exception) {
            rootContainer = null
            layoutParams = null
        }
    }

    fun hide() {
        collectJob?.cancel()
        collectJob = null
        scope?.cancel()
        scope = null

        val view = rootContainer
        rootContainer = null
        layoutParams = null
        if (view != null) {
            try {
                windowManager.removeView(view)
            } catch (_: Exception) {
            }
        }
    }

    private fun startCollectingState() {
        scope?.cancel()
        val newScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
        scope = newScope
        collectJob = newScope.launch {
            combine(
                controller.metrics,
                controller.settingsRepository.settingsFlow
            ) { metrics, settings ->
                metrics to settings.overlay
            }.collect { (metrics, overlaySettings) ->
                render(metrics, overlaySettings)
            }
        }
    }

    private fun dp(value: Float): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            context.resources.displayMetrics
        ).roundToInt()

    private fun screenDimensions(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = windowManager.currentWindowMetrics.bounds
            bounds.width() to bounds.height()
        } else {
            val dm = context.resources.displayMetrics
            dm.widthPixels to dm.heightPixels
        }
    }

    private fun createLayoutParams(settings: OverlaySettings): WindowManager.LayoutParams {
        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        var flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        if (settings.lockTouchThrough) {
            flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }

        val (x, y) = resolveCoordinates(settings)

        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            windowType,
            flags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x
            this.y = y
        }
    }

    private fun resolveCoordinates(settings: OverlaySettings): Pair<Int, Int> {
        val (screenW, screenH) = screenDimensions()
        val margin = dp(16f)
        val estimatedWidth = dp(210f)
        val estimatedHeight = dp(110f)
        return when (settings.positionPreset) {
            OverlayPositionPreset.TOP_LEFT -> margin to dp(72f)
            OverlayPositionPreset.TOP_RIGHT -> (screenW - estimatedWidth - margin).coerceAtLeast(margin) to dp(72f)
            OverlayPositionPreset.BOTTOM_LEFT -> margin to (screenH - estimatedHeight - dp(84f)).coerceAtLeast(margin)
            OverlayPositionPreset.BOTTOM_RIGHT ->
                (screenW - estimatedWidth - margin).coerceAtLeast(margin) to
                    (screenH - estimatedHeight - dp(84f)).coerceAtLeast(margin)
            OverlayPositionPreset.CUSTOM ->
                settings.savedX.coerceIn(0, (screenW - dp(80f)).coerceAtLeast(0)) to
                    settings.savedY.coerceIn(0, (screenH - dp(48f)).coerceAtLeast(0))
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun attachDragListener(view: View, params: WindowManager.LayoutParams) {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false

        view.setOnTouchListener { _, event ->
            val currentSettings = controller.latestSettings.value.overlay
            if (currentSettings.lockTouchThrough) return@setOnTouchListener false

            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).roundToInt()
                    val dy = (event.rawY - initialTouchY).roundToInt()
                    if (!isDragging && (abs(dx) > dp(6f) || abs(dy) > dp(6f))) {
                        isDragging = true
                    }
                    if (isDragging) {
                        val (screenW, screenH) = screenDimensions()
                        val viewW = view.width.coerceAtLeast(dp(120f))
                        val viewH = view.height.coerceAtLeast(dp(44f))
                        params.x = (initialX + dx).coerceIn(0, (screenW - viewW).coerceAtLeast(0))
                        params.y = (initialY + dy).coerceIn(0, (screenH - viewH).coerceAtLeast(0))
                        try {
                            windowManager.updateViewLayout(view, params)
                        } catch (_: Exception) {
                        }
                    }
                    true
                }

                MotionEvent.ACTION_UP -> {
                    if (isDragging) {
                        scope?.launch {
                            controller.settingsRepository.saveOverlayCoordinates(params.x, params.y)
                        }
                    } else {
                        isExpanded = !isExpanded
                        render(controller.metrics.value, controller.latestSettings.value.overlay)
                    }
                    true
                }

                else -> false
            }
        }
    }

    private fun buildOverlayView(): LinearLayout {
        val root = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10f), dp(7f), dp(10f), dp(7f))
        }

        // Compact header row (always visible)
        val headerRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val dot = View(context).apply {
            val size = dp(9f)
            layoutParams = LinearLayout.LayoutParams(size, size).apply {
                marginEnd = dp(7f)
            }
        }
        statusDot = dot

        val ping = TextView(context).apply {
            typeface = monoTypeface
            includeFontPadding = false
        }
        pingText = ping

        val badge = TextView(context).apply {
            typeface = monoTypeface
            includeFontPadding = false
            setPadding(dp(5f), dp(1.5f), dp(5f), dp(1.5f))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                marginStart = dp(6f)
            }
        }
        methodBadge = badge

        val meta = TextView(context).apply {
            typeface = monoTypeface
            includeFontPadding = false
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                marginStart = dp(8f)
            }
        }
        compactMetaText = meta

        val chevron = TextView(context).apply {
            typeface = headingTypeface
            text = "▾"
            includeFontPadding = false
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                marginStart = dp(7f)
            }
        }
        expandChevron = chevron

        headerRow.addView(dot)
        headerRow.addView(ping)
        headerRow.addView(badge)
        headerRow.addView(meta)
        headerRow.addView(chevron)
        root.addView(headerRow)

        // Expanded details section
        val expanded = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(0, dp(6f), 0, 0)
        }
        expandedSection = expanded

        val statusLabel = TextView(context).apply {
            typeface = headingTypeface
            includeFontPadding = false
        }
        statusLabelText = statusLabel

        val jitterLoss = TextView(context).apply {
            typeface = monoTypeface
            includeFontPadding = false
            setPadding(0, dp(3f), 0, 0)
        }
        jitterLossText = jitterLoss

        val avgMinMax = TextView(context).apply {
            typeface = monoTypeface
            includeFontPadding = false
            setPadding(0, dp(2f), 0, 0)
        }
        avgMinMaxText = avgMinMax

        val connView = TextView(context).apply {
            typeface = monoTypeface
            includeFontPadding = false
            setPadding(0, dp(2f), 0, 0)
        }
        connectionText = connView

        val actionsRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(7f), 0, 0)
        }

        val pauseBtn = makeActionChip("PAUSE") {
            if (controller.metrics.value.isMonitoring) {
                controller.togglePause()
            } else {
                controller.startMonitoring()
            }
        }
        pauseButton = pauseBtn

        val openBtn = makeActionChip("APP") {
            val launchIntent = Intent(context, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            context.startActivity(launchIntent)
        }
        openAppButton = openBtn

        val hideBtn = makeActionChip("HIDE") {
            onHideRequested()
        }
        hideButton = hideBtn

        actionsRow.addView(pauseBtn)
        actionsRow.addView(openBtn)
        actionsRow.addView(hideBtn)

        expanded.addView(statusLabel)
        expanded.addView(jitterLoss)
        expanded.addView(avgMinMax)
        expanded.addView(connView)
        expanded.addView(actionsRow)
        root.addView(expanded)

        return root
    }

    private fun makeActionChip(label: String, onClick: () -> Unit): TextView {
        return TextView(context).apply {
            text = label
            typeface = headingTypeface
            setPadding(dp(8f), dp(4f), dp(8f), dp(4f))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                marginEnd = dp(6f)
            }
            setOnClickListener { onClick() }
        }
    }

    private fun render(metrics: NetworkMetricsSnapshot, settings: OverlaySettings) {
        val root = rootContainer ?: return
        val params = layoutParams ?: return

        val bgBase = settings.effectiveBgColor()
        val alphaInt = (settings.alpha.coerceIn(0.30f, 1.0f) * 255).roundToInt()
        val bgColor = Color.argb(
            alphaInt,
            Color.red(bgBase),
            Color.green(bgBase),
            Color.blue(bgBase)
        )
        val borderColor = settings.effectiveBorderColor()
        val textColor = settings.effectiveTextColor()
        val accentColor = settings.effectiveAccentColor()
        val qualityColor = metrics.quality.argb

        // Update card background
        root.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(12f * settings.size.scale).toFloat()
            setColor(bgColor)
            setStroke(dp(1.2f), borderColor)
        }

        // Update WindowManager touch-through & preset position if changed
        var layoutDirty = false
        val desiredFlags = if (settings.lockTouchThrough) {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        } else {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        }
        if (params.flags != desiredFlags) {
            params.flags = desiredFlags
            layoutDirty = true
        }
        if (lastAppliedPreset != settings.positionPreset &&
            settings.positionPreset != OverlayPositionPreset.CUSTOM
        ) {
            val (nx, ny) = resolveCoordinates(settings)
            params.x = nx
            params.y = ny
            lastAppliedPreset = settings.positionPreset
            layoutDirty = true
        } else {
            lastAppliedPreset = settings.positionPreset
        }

        val scale = settings.size.scale
        val fontSp = settings.fontSizeSp

        statusDot?.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(qualityColor)
        }

        val pingDisplay = when {
            !metrics.isMonitoring -> "IDLE"
            metrics.isPaused || metrics.isScreenOffPaused -> "PAUSED"
            metrics.livePingMs != null -> "${metrics.livePingMs} ms"
            else -> "--- ms"
        }

        pingText?.apply {
            text = pingDisplay
            setTextColor(if (metrics.livePingMs != null && metrics.isMonitoring) qualityColor else textColor)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, fontSp * 1.15f * scale)
        }

        methodBadge?.apply {
            visibility = if (settings.showProbeMethod) View.VISIBLE else View.GONE
            text = metrics.activeMethod.shortBadge
            setTextColor(accentColor)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, (fontSp * 0.72f * scale).coerceAtLeast(8.5f))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(5f).toFloat()
                setColor(Color.argb(40, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor)))
                setStroke(dp(0.8f), Color.argb(120, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor)))
            }
        }

        val compactMetaParts = buildList {
            if (!isExpanded) {
                if (settings.showJitter) add("J:${metrics.jitterMs}ms")
                if (settings.showPacketLoss) add("L:${metrics.packetLossPercent.roundToInt()}%")
                if (settings.showConnectionType) add(metrics.connectivity.connectionType.shortLabel)
            }
        }

        compactMetaText?.apply {
            visibility = if (compactMetaParts.isNotEmpty()) View.VISIBLE else View.GONE
            text = compactMetaParts.joinToString(" • ")
            setTextColor(textColor)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, (fontSp * 0.85f * scale).coerceAtLeast(9.5f))
        }

        expandChevron?.apply {
            text = if (isExpanded) "▴" else "▾"
            setTextColor(accentColor)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, fontSp * scale)
        }

        expandedSection?.visibility = if (isExpanded) View.VISIBLE else View.GONE

        if (isExpanded) {
            val detailFontSp = (fontSp * 0.85f * scale).coerceAtLeast(9.5f)
            statusLabelText?.apply {
                text = "NETWORK: ${metrics.quality.shortStatus} (${metrics.targetDisplay})"
                setTextColor(qualityColor)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, detailFontSp)
            }

            jitterLossText?.apply {
                val showJ = settings.showJitter
                val showL = settings.showPacketLoss
                visibility = if (showJ || showL) View.VISIBLE else View.GONE
                val parts = buildList {
                    if (showJ) add("JITTER: ${metrics.jitterMs} ms")
                    if (showL) add("LOSS: ${String.format("%.1f", metrics.packetLossPercent)}%")
                }
                text = parts.joinToString("   ")
                setTextColor(textColor)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, detailFontSp)
            }

            avgMinMaxText?.apply {
                visibility = if (settings.showAvgMinMax) View.VISIBLE else View.GONE
                text = "AVG ${metrics.avgPingMs}  MIN ${metrics.minPingMs}  MAX ${metrics.maxPingMs} ms"
                setTextColor(textColor)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, detailFontSp)
            }

            connectionText?.apply {
                visibility = if (settings.showConnectionType) View.VISIBLE else View.GONE
                text = "CONN: ${metrics.connectivity.transportDetail}"
                setTextColor(textColor)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, detailFontSp)
            }

            val chipBg = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(6f).toFloat()
                setColor(Color.argb(46, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor)))
                setStroke(dp(0.8f), borderColor)
            }
            val chipFont = (fontSp * 0.75f * scale).coerceAtLeast(9f)
            pauseButton?.apply {
                text = when {
                    !metrics.isMonitoring -> "START"
                    metrics.isPaused -> "RESUME"
                    else -> "PAUSE"
                }
                setTextColor(accentColor)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, chipFont)
                background = chipBg
            }
            openAppButton?.apply {
                setTextColor(textColor)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, chipFont)
                background = chipBg.constantState?.newDrawable()?.mutate()
            }
            hideButton?.apply {
                setTextColor(0xFFFF6B81.toInt())
                setTextSize(TypedValue.COMPLEX_UNIT_SP, chipFont)
                background = chipBg.constantState?.newDrawable()?.mutate()
            }
        }

        if (layoutDirty) {
            try {
                windowManager.updateViewLayout(root, params)
            } catch (_: Exception) {
            }
        }
    }
}
