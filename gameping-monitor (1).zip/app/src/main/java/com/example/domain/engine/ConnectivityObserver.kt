package com.example.domain.engine

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.Build
import com.example.domain.model.ConnectionType
import com.example.domain.model.ConnectivityState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ConnectivityObserver(private val context: Context) {

    private val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private val wifiManager =
        context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager

    private val _state = MutableStateFlow(readCurrentConnectivity())
    val state: StateFlow<ConnectivityState> = _state.asStateFlow()

    private var registered = false

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            refresh()
        }

        override fun onLost(network: Network) {
            refresh()
        }

        override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
            refresh()
        }
    }

    fun startObserving() {
        if (registered) return
        try {
            val request = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()
            connectivityManager.registerNetworkCallback(request, networkCallback)
            registered = true
            refresh()
        } catch (_: Exception) {
            refresh()
        }
    }

    fun stopObserving() {
        if (!registered) return
        try {
            connectivityManager.unregisterNetworkCallback(networkCallback)
        } catch (_: Exception) {
        } finally {
            registered = false
        }
    }

    fun refresh() {
        _state.value = readCurrentConnectivity()
    }

    @Suppress("DEPRECATION")
    private fun readCurrentConnectivity(): ConnectivityState {
        val activeNetwork = connectivityManager.activeNetwork
            ?: return ConnectivityState(
                isConnected = false,
                isInternetValidated = false,
                connectionType = ConnectionType.NONE,
                transportDetail = "No active network"
            )

        val caps = connectivityManager.getNetworkCapabilities(activeNetwork)
            ?: return ConnectivityState(
                isConnected = false,
                isInternetValidated = false,
                connectionType = ConnectionType.NONE,
                transportDetail = "Network capabilities unavailable"
            )

        val hasInternet = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        val isValidated = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        val isVpn = caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
        val isMetered = !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)

        val type = when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> ConnectionType.WIFI
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> ConnectionType.ETHERNET
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> ConnectionType.MOBILE
            isVpn -> ConnectionType.VPN
            hasInternet -> ConnectionType.MOBILE
            else -> ConnectionType.NONE
        }

        var wifiFreq: Int? = null
        var wifiLinkSpeed: Int? = null
        var signalDbm: Int? = null

        if (type == ConnectionType.WIFI) {
            val transportWifi = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                caps.transportInfo as? WifiInfo
            } else {
                null
            }
            val wifiInfo = transportWifi ?: try {
                wifiManager?.connectionInfo
            } catch (_: SecurityException) {
                null
            }
            if (wifiInfo != null) {
                if (wifiInfo.frequency > 0) wifiFreq = wifiInfo.frequency
                if (wifiInfo.linkSpeed > 0) wifiLinkSpeed = wifiInfo.linkSpeed
                if (wifiInfo.rssi in -120..-1) signalDbm = wifiInfo.rssi
            }
            if (signalDbm == null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val capSig = caps.signalStrength
                if (capSig != NetworkCapabilities.SIGNAL_STRENGTH_UNSPECIFIED) {
                    signalDbm = capSig
                }
            }
        }

        val detail = buildString {
            append(type.displayName)
            if (type == ConnectionType.WIFI) {
                wifiFreq?.let { freq ->
                    val band = when {
                        freq >= 5925 -> "6GHz"
                        freq >= 4900 -> "5GHz"
                        else -> "2.4GHz"
                    }
                    append(" • $band")
                }
                wifiLinkSpeed?.let { append(" • ${it}Mbps") }
            }
            if (isVpn && type != ConnectionType.VPN) {
                append(" • VPN")
            }
            if (!isValidated && hasInternet) {
                append(" (Unvalidated)")
            }
        }

        return ConnectivityState(
            isConnected = hasInternet,
            isInternetValidated = isValidated,
            connectionType = type,
            transportDetail = detail,
            isVpnActive = isVpn,
            isMetered = isMetered,
            linkDownstreamKbps = caps.linkDownstreamBandwidthKbps.takeIf { it > 0 },
            linkUpstreamKbps = caps.linkUpstreamBandwidthKbps.takeIf { it > 0 },
            wifiFrequencyMhz = wifiFreq,
            wifiLinkSpeedMbps = wifiLinkSpeed,
            signalStrengthDbm = signalDbm
        )
    }
}
