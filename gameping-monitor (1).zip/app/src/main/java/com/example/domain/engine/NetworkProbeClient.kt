package com.example.domain.engine

import com.example.domain.model.ProbeBreakdown
import com.example.domain.model.ProbeMethod
import com.example.domain.model.ProbeSample
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.CacheControl
import okhttp3.Call
import okhttp3.EventListener
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import java.util.regex.Pattern
import kotlin.math.roundToInt

class NetworkProbeClient {

    private val sampleIdCounter = AtomicLong(1L)
    private val icmpTimePattern = Pattern.compile("time=([0-9]+(?:\\.[0-9]+)?)\\s*ms")

    private val baseHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(4, TimeUnit.SECONDS)
        .writeTimeout(4, TimeUnit.SECONDS)
        .retryOnConnectionFailure(false)
        .build()

    suspend fun measure(
        method: ProbeMethod,
        host: String,
        port: Int,
        httpsUrl: String,
        dnsHost: String,
        timeoutMs: Int = 2500
    ): ProbeSample = withContext(Dispatchers.IO) {
        when (method) {
            ProbeMethod.TCP_CONNECT -> measureTcpConnect(host, port, timeoutMs)
            ProbeMethod.ICMP_ECHO -> measureIcmpEcho(host, timeoutMs)
            ProbeMethod.HTTPS_RESPONSE -> measureHttpsResponse(httpsUrl, timeoutMs)
            ProbeMethod.DNS_LOOKUP -> measureDnsLookup(dnsHost)
        }
    }

    suspend fun measureTcpConnect(
        host: String,
        port: Int,
        timeoutMs: Int = 2500
    ): ProbeSample = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val id = sampleIdCounter.getAndIncrement()
        val sanitizedHost = host.trim()
        val validPort = port.coerceIn(1, 65535)
        var socket: Socket? = null
        try {
            val dnsStart = System.nanoTime()
            val address = InetAddress.getByName(sanitizedHost)
            val dnsMs = (System.nanoTime() - dnsStart) / 1_000_000.0

            socket = Socket()
            val connectStart = System.nanoTime()
            socket.connect(InetSocketAddress(address, validPort), timeoutMs)
            val connectMs = (System.nanoTime() - connectStart) / 1_000_000.0

            ProbeSample(
                id = id,
                timestampMs = now,
                latencyMs = connectMs.roundToInt().coerceAtLeast(1),
                jitterMs = 0,
                isSuccess = true,
                method = ProbeMethod.TCP_CONNECT,
                targetHost = "$sanitizedHost:$validPort",
                breakdown = ProbeBreakdown(dnsMs = dnsMs, tcpMs = connectMs)
            )
        } catch (e: Exception) {
            ProbeSample(
                id = id,
                timestampMs = now,
                latencyMs = null,
                jitterMs = 0,
                isSuccess = false,
                method = ProbeMethod.TCP_CONNECT,
                targetHost = "$sanitizedHost:$validPort",
                errorMessage = e.localizedMessage ?: "TCP connection failed"
            )
        } finally {
            try {
                socket?.close()
            } catch (_: IOException) {
            }
        }
    }

    suspend fun measureIcmpEcho(
        host: String,
        timeoutMs: Int = 2500
    ): ProbeSample = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val id = sampleIdCounter.getAndIncrement()
        val sanitizedHost = host.trim()
        val timeoutSec = ((timeoutMs + 999) / 1000).coerceIn(1, 5)
        var process: Process? = null

        try {
            val result = withTimeoutOrNull(timeoutMs.toLong() + 500L) {
                val startNs = System.nanoTime()
                process = ProcessBuilder(
                    "/system/bin/ping",
                    "-c", "1",
                    "-W", timeoutSec.toString(),
                    sanitizedHost
                )
                    .redirectErrorStream(true)
                    .start()

                val output = process!!.inputStream.bufferedReader().use { it.readText() }
                val exitCode = process!!.waitFor()
                val elapsedMs = (System.nanoTime() - startNs) / 1_000_000.0
                Triple(exitCode, output, elapsedMs)
            }

            if (result == null) {
                return@withContext ProbeSample(
                    id = id,
                    timestampMs = now,
                    latencyMs = null,
                    jitterMs = 0,
                    isSuccess = false,
                    method = ProbeMethod.ICMP_ECHO,
                    targetHost = sanitizedHost,
                    errorMessage = "ICMP Echo timed out (${timeoutSec}s)"
                )
            }

            val (exitCode, output, fallbackElapsed) = result
            if (exitCode == 0) {
                val matcher = icmpTimePattern.matcher(output)
                val parsedMs = if (matcher.find()) {
                    matcher.group(1)?.toDoubleOrNull()
                } else {
                    null
                }
                val rtt = (parsedMs ?: fallbackElapsed).roundToInt().coerceAtLeast(1)
                ProbeSample(
                    id = id,
                    timestampMs = now,
                    latencyMs = rtt,
                    jitterMs = 0,
                    isSuccess = true,
                    method = ProbeMethod.ICMP_ECHO,
                    targetHost = sanitizedHost
                )
            } else {
                val reason = when {
                    output.contains("Operation not permitted", ignoreCase = true) ||
                        output.contains("Permission denied", ignoreCase = true) ->
                        "ICMP blocked by device policy; switch to TCP Connect"
                    output.contains("100% packet loss", ignoreCase = true) ->
                        "ICMP Echo packet loss (100%)"
                    output.isNotBlank() ->
                        output.lineSequence().firstOrNull { it.isNotBlank() }?.take(80)
                            ?: "ICMP Echo failed (exit $exitCode)"
                    else -> "ICMP Echo failed (exit $exitCode)"
                }
                ProbeSample(
                    id = id,
                    timestampMs = now,
                    latencyMs = null,
                    jitterMs = 0,
                    isSuccess = false,
                    method = ProbeMethod.ICMP_ECHO,
                    targetHost = sanitizedHost,
                    errorMessage = reason
                )
            }
        } catch (e: Exception) {
            ProbeSample(
                id = id,
                timestampMs = now,
                latencyMs = null,
                jitterMs = 0,
                isSuccess = false,
                method = ProbeMethod.ICMP_ECHO,
                targetHost = sanitizedHost,
                errorMessage = "ICMP unavailable: ${e.localizedMessage ?: "error"}"
            )
        } finally {
            process?.destroyForcibly()
        }
    }

    suspend fun measureHttpsResponse(
        url: String,
        timeoutMs: Int = 3500
    ): ProbeSample = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val id = sampleIdCounter.getAndIncrement()
        val normalizedUrl = if (url.startsWith("http://") || url.startsWith("https://")) {
            url.trim()
        } else {
            "https://${url.trim()}"
        }

        var dnsStartNs = 0L
        var dnsMs: Double? = null
        var connectStartNs = 0L
        var tcpMs: Double? = null
        var tlsStartNs = 0L
        var tlsMs: Double? = null
        var reqStartNs = 0L
        var ttfbMs: Double? = null

        val listener = object : EventListener() {
            override fun dnsStart(call: Call, domainName: String) {
                dnsStartNs = System.nanoTime()
            }

            override fun dnsEnd(call: Call, domainName: String, inetAddressList: List<InetAddress>) {
                if (dnsStartNs > 0L) dnsMs = (System.nanoTime() - dnsStartNs) / 1_000_000.0
            }

            override fun connectStart(call: Call, inetSocketAddress: InetSocketAddress, proxy: java.net.Proxy) {
                connectStartNs = System.nanoTime()
            }

            override fun secureConnectStart(call: Call) {
                tlsStartNs = System.nanoTime()
            }

            override fun secureConnectEnd(call: Call, handshake: okhttp3.Handshake?) {
                if (tlsStartNs > 0L) tlsMs = (System.nanoTime() - tlsStartNs) / 1_000_000.0
            }

            override fun connectEnd(
                call: Call,
                inetSocketAddress: InetSocketAddress,
                proxy: java.net.Proxy,
                protocol: okhttp3.Protocol?
            ) {
                if (connectStartNs > 0L) {
                    val totalConnect = (System.nanoTime() - connectStartNs) / 1_000_000.0
                    tcpMs = (totalConnect - (tlsMs ?: 0.0)).coerceAtLeast(0.0)
                }
            }

            override fun requestHeadersStart(call: Call) {
                reqStartNs = System.nanoTime()
            }

            override fun responseHeadersStart(call: Call) {
                if (reqStartNs > 0L) ttfbMs = (System.nanoTime() - reqStartNs) / 1_000_000.0
            }
        }

        val callClient = baseHttpClient.newBuilder()
            .callTimeout(timeoutMs.toLong(), TimeUnit.MILLISECONDS)
            .eventListener(listener)
            .build()

        val request = Request.Builder()
            .url(normalizedUrl)
            .header("Connection", "close")
            .cacheControl(CacheControl.FORCE_NETWORK)
            .head()
            .build()

        try {
            val totalStart = System.nanoTime()
            callClient.newCall(request).execute().use { response ->
                val totalMs = (System.nanoTime() - totalStart) / 1_000_000.0
                if (response.isSuccessful || response.code in 200..399) {
                    ProbeSample(
                        id = id,
                        timestampMs = now,
                        latencyMs = totalMs.roundToInt().coerceAtLeast(1),
                        jitterMs = 0,
                        isSuccess = true,
                        method = ProbeMethod.HTTPS_RESPONSE,
                        targetHost = normalizedUrl.removePrefix("https://").substringBefore("/"),
                        breakdown = ProbeBreakdown(
                            dnsMs = dnsMs,
                            tcpMs = tcpMs,
                            tlsMs = tlsMs,
                            ttfbMs = ttfbMs ?: totalMs
                        )
                    )
                } else {
                    ProbeSample(
                        id = id,
                        timestampMs = now,
                        latencyMs = null,
                        jitterMs = 0,
                        isSuccess = false,
                        method = ProbeMethod.HTTPS_RESPONSE,
                        targetHost = normalizedUrl.removePrefix("https://").substringBefore("/"),
                        errorMessage = "HTTP ${response.code}"
                    )
                }
            }
        } catch (e: Exception) {
            ProbeSample(
                id = id,
                timestampMs = now,
                latencyMs = null,
                jitterMs = 0,
                isSuccess = false,
                method = ProbeMethod.HTTPS_RESPONSE,
                targetHost = normalizedUrl.removePrefix("https://").substringBefore("/"),
                errorMessage = e.localizedMessage ?: "HTTPS probe failed"
            )
        }
    }

    suspend fun measureDnsLookup(hostname: String): ProbeSample = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        val id = sampleIdCounter.getAndIncrement()
        val cleanHost = hostname.trim()
            .removePrefix("https://")
            .removePrefix("http://")
            .substringBefore("/")
            .substringBefore(":")
        try {
            val start = System.nanoTime()
            val resolved = InetAddress.getAllByName(cleanHost)
            val dnsMs = (System.nanoTime() - start) / 1_000_000.0
            if (resolved.isNotEmpty()) {
                ProbeSample(
                    id = id,
                    timestampMs = now,
                    latencyMs = dnsMs.roundToInt().coerceAtLeast(1),
                    jitterMs = 0,
                    isSuccess = true,
                    method = ProbeMethod.DNS_LOOKUP,
                    targetHost = cleanHost,
                    breakdown = ProbeBreakdown(dnsMs = dnsMs)
                )
            } else {
                ProbeSample(
                    id = id,
                    timestampMs = now,
                    latencyMs = null,
                    jitterMs = 0,
                    isSuccess = false,
                    method = ProbeMethod.DNS_LOOKUP,
                    targetHost = cleanHost,
                    errorMessage = "Empty DNS response"
                )
            }
        } catch (e: Exception) {
            ProbeSample(
                id = id,
                timestampMs = now,
                latencyMs = null,
                jitterMs = 0,
                isSuccess = false,
                method = ProbeMethod.DNS_LOOKUP,
                targetHost = cleanHost,
                errorMessage = e.localizedMessage ?: "DNS lookup failed"
            )
        }
    }
}
