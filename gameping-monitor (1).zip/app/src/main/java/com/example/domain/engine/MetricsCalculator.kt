package com.example.domain.engine

import com.example.domain.model.NetworkQuality
import com.example.domain.model.NetworkThresholds
import com.example.domain.model.ProbeSample
import kotlin.math.abs
import kotlin.math.roundToInt

object MetricsCalculator {

    /**
     * Computes consecutive latency delta jitter (ms) across successful probes in the window.
     */
    fun calculateJitterMs(samples: List<ProbeSample>): Int {
        val latencies = samples.mapNotNull { if (it.isSuccess) it.latencyMs else null }
        if (latencies.size < 2) return 0
        var diffSum = 0L
        for (i in 1 until latencies.size) {
            diffSum += abs(latencies[i] - latencies[i - 1])
        }
        return (diffSum.toDouble() / (latencies.size - 1)).roundToInt()
    }

    /**
     * Computes instant jitter between current and previous successful sample.
     */
    fun calculateInstantJitter(previousLatencyMs: Int?, currentLatencyMs: Int?): Int {
        if (previousLatencyMs == null || currentLatencyMs == null) return 0
        return abs(currentLatencyMs - previousLatencyMs)
    }

    /**
     * Computes packet loss percentage over a list of probes (0f..100f).
     */
    fun calculatePacketLossPercent(totalProbes: Int, failedProbes: Int): Float {
        if (totalProbes <= 0) return 0f
        return ((failedProbes.toFloat() / totalProbes.toFloat()) * 100f).coerceIn(0f, 100f)
    }

    fun calculateWindowPacketLossPercent(samples: List<ProbeSample>, windowSize: Int = 30): Float {
        if (samples.isEmpty()) return 0f
        val window = if (samples.size > windowSize) samples.takeLast(windowSize) else samples
        val failed = window.count { !it.isSuccess }
        return calculatePacketLossPercent(window.size, failed)
    }

    /**
     * Evaluates overall gaming network quality based on connectivity, ping, jitter, and packet loss.
     */
    fun evaluateQuality(
        isConnected: Boolean,
        livePingMs: Int?,
        jitterMs: Int,
        packetLossPercent: Float,
        thresholds: NetworkThresholds
    ): NetworkQuality {
        if (!isConnected) return NetworkQuality.OFFLINE
        if (packetLossPercent >= 99.9f) return NetworkQuality.OFFLINE
        if (livePingMs == null) {
            return if (packetLossPercent > 10f) NetworkQuality.POOR else NetworkQuality.UNSTABLE
        }

        if (packetLossPercent > 10f || livePingMs > thresholds.unstableMaxMs) {
            return NetworkQuality.POOR
        }

        if (
            packetLossPercent > thresholds.packetLossWarningPercent ||
            livePingMs > thresholds.goodMaxMs ||
            jitterMs > thresholds.jitterWarningMs
        ) {
            return NetworkQuality.UNSTABLE
        }

        if (livePingMs <= thresholds.excellentMaxMs && jitterMs <= 10 && packetLossPercent == 0f) {
            return NetworkQuality.EXCELLENT
        }

        return NetworkQuality.GOOD
    }
}
