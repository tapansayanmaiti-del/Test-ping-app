package com.example.domain.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.AmberUnstable
import com.example.ui.theme.CrimsonPoor
import com.example.ui.theme.CyanGood
import com.example.ui.theme.EmeraldExcellent
import com.example.ui.theme.OfflineGray

enum class ProbeMethod(
    val displayName: String,
    val shortBadge: String,
    val description: String
) {
    TCP_CONNECT(
        displayName = "TCP Connect",
        shortBadge = "TCP",
        description = "Measures TCP SYN/SYN-ACK handshake latency to the target port."
    ),
    ICMP_ECHO(
        displayName = "ICMP Echo",
        shortBadge = "ICMP",
        description = "Measures raw ICMP Echo ping via system ping binary (may be blocked on some networks or devices)."
    ),
    HTTPS_RESPONSE(
        displayName = "HTTPS Response",
        shortBadge = "HTTPS",
        description = "Measures full HTTPS endpoint response latency including TLS and server TTFB."
    ),
    DNS_LOOKUP(
        displayName = "DNS Lookup",
        shortBadge = "DNS",
        description = "Measures hostname resolution latency via the active system DNS resolver."
    )
}

enum class NetworkQuality(
    val label: String,
    val shortStatus: String,
    val color: Color,
    val argb: Int
) {
    EXCELLENT(
        label = "Excellent",
        shortStatus = "STABLE",
        color = EmeraldExcellent,
        argb = 0xFF00FF9D.toInt()
    ),
    GOOD(
        label = "Good",
        shortStatus = "GOOD",
        color = CyanGood,
        argb = 0xFF00E5FF.toInt()
    ),
    UNSTABLE(
        label = "Unstable",
        shortStatus = "UNSTABLE",
        color = AmberUnstable,
        argb = 0xFFFFB300.toInt()
    ),
    POOR(
        label = "Poor",
        shortStatus = "POOR",
        color = CrimsonPoor,
        argb = 0xFFFF3B5C.toInt()
    ),
    OFFLINE(
        label = "No Internet",
        shortStatus = "OFFLINE",
        color = OfflineGray,
        argb = 0xFF6B7280.toInt()
    )
}

enum class ConnectionType(val displayName: String, val shortLabel: String) {
    WIFI("Wi-Fi", "Wi-Fi"),
    MOBILE("Mobile Data", "Mobile"),
    ETHERNET("Ethernet", "Ethernet"),
    VPN("VPN Tunnel", "VPN"),
    NONE("No Connection", "Offline")
}

enum class TestServerPreset(
    val id: String,
    val label: String,
    val host: String,
    val port: Int,
    val httpsUrl: String,
    val dnsHost: String
) {
    CLOUDFLARE(
        id = "cloudflare",
        label = "Cloudflare Edge (1.1.1.1)",
        host = "1.1.1.1",
        port = 443,
        httpsUrl = "https://1.1.1.1/cdn-cgi/trace",
        dnsHost = "one.one.one.one"
    ),
    GOOGLE_DNS(
        id = "google",
        label = "Google Public (8.8.8.8)",
        host = "8.8.8.8",
        port = 443,
        httpsUrl = "https://connectivitycheck.gstatic.com/generate_204",
        dnsHost = "dns.google"
    ),
    QUAD9(
        id = "quad9",
        label = "Quad9 Anycast (9.9.9.9)",
        host = "9.9.9.9",
        port = 443,
        httpsUrl = "https://dns.quad9.net/dns-query",
        dnsHost = "dns.quad9.net"
    ),
    CUSTOM(
        id = "custom",
        label = "Custom Server",
        host = "1.1.1.1",
        port = 443,
        httpsUrl = "https://1.1.1.1/cdn-cgi/trace",
        dnsHost = "cloudflare.com"
    );

    companion object {
        fun fromId(id: String): TestServerPreset =
            entries.firstOrNull { it.id == id } ?: CLOUDFLARE
    }
}

data class ProbeBreakdown(
    val dnsMs: Double? = null,
    val tcpMs: Double? = null,
    val tlsMs: Double? = null,
    val ttfbMs: Double? = null
)

data class ProbeSample(
    val id: Long,
    val timestampMs: Long,
    val latencyMs: Int?,
    val jitterMs: Int,
    val isSuccess: Boolean,
    val method: ProbeMethod,
    val targetHost: String,
    val errorMessage: String? = null,
    val breakdown: ProbeBreakdown? = null
)

enum class LiveEventType {
    INTERRUPTION,
    RECOVERY,
    HIGH_LATENCY_SPIKE,
    PACKET_LOSS_BURST,
    SESSION_STARTED
}

data class LiveNetworkEvent(
    val id: Long,
    val timestampMs: Long,
    val type: LiveEventType,
    val title: String,
    val detail: String
)

data class NetworkThresholds(
    val excellentMaxMs: Int = 40,
    val goodMaxMs: Int = 80,
    val unstableMaxMs: Int = 150,
    val jitterWarningMs: Int = 25,
    val packetLossWarningPercent: Float = 2f
)

data class ConnectivityState(
    val isConnected: Boolean = false,
    val isInternetValidated: Boolean = false,
    val connectionType: ConnectionType = ConnectionType.NONE,
    val transportDetail: String = "Checking network...",
    val isVpnActive: Boolean = false,
    val isMetered: Boolean = false,
    val linkDownstreamKbps: Int? = null,
    val linkUpstreamKbps: Int? = null,
    val wifiFrequencyMhz: Int? = null,
    val wifiLinkSpeedMbps: Int? = null,
    val signalStrengthDbm: Int? = null
)

data class NetworkMetricsSnapshot(
    val livePingMs: Int? = null,
    val avgPingMs: Int = 0,
    val minPingMs: Int = 0,
    val maxPingMs: Int = 0,
    val jitterMs: Int = 0,
    val packetLossPercent: Float = 0f,
    val quality: NetworkQuality = NetworkQuality.OFFLINE,
    val connectivity: ConnectivityState = ConnectivityState(),
    val activeMethod: ProbeMethod = ProbeMethod.TCP_CONNECT,
    val targetDisplay: String = "1.1.1.1:443",
    val totalProbes: Int = 0,
    val failedProbes: Int = 0,
    val sessionDurationSec: Long = 0L,
    val isMonitoring: Boolean = false,
    val isPaused: Boolean = false,
    val isScreenOffPaused: Boolean = false,
    val lastDnsMs: Int? = null,
    val lastError: String? = null,
    val recentSamples: List<ProbeSample> = emptyList(),
    val recentEvents: List<LiveNetworkEvent> = emptyList()
)
