package com.example

import android.app.Application
import com.example.data.local.GamePingDatabase
import com.example.data.local.NetworkHistoryRepository
import com.example.data.monitor.NetworkMonitorController
import com.example.data.preferences.SettingsRepository

class GamePingApplication : Application() {

    lateinit var settingsRepository: SettingsRepository
        private set

    lateinit var historyRepository: NetworkHistoryRepository
        private set

    lateinit var monitorController: NetworkMonitorController
        private set

    override fun onCreate() {
        super.onCreate()
        settingsRepository = SettingsRepository(this)
        val db = GamePingDatabase.getInstance(this)
        historyRepository = NetworkHistoryRepository(db.networkHistoryDao())
        monitorController = NetworkMonitorController(
            context = this,
            settingsRepository = settingsRepository,
            historyRepository = historyRepository
        )
    }
}
