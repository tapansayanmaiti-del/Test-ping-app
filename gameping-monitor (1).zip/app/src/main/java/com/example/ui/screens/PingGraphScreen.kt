package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.preferences.AppSettings
import com.example.domain.model.NetworkMetricsSnapshot
import com.example.ui.components.AnimatedPingChart
import com.example.ui.components.FormatUtils
import com.example.ui.components.StatusBadgePill
import com.example.ui.components.TacticalCard
import com.example.ui.theme.AmberUnstable
import com.example.ui.theme.BorderSlate
import com.example.ui.theme.CrimsonPoor
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DeepSlate
import com.example.ui.theme.EmeraldExcellent
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun PingGraphScreen(
    metrics: NetworkMetricsSnapshot,
    settings: AppSettings,
    onStartMonitoring: () -> Unit,
    onStopMonitoring: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showJitter by remember { mutableStateOf(true) }
    var showThresholds by remember { mutableStateOf(true) }
    var selectedSampleIndex by remember { mutableStateOf<Int?>(null) }

    val samples = metrics.recentSamples
    val inspectedSample = selectedSampleIndex?.let { idx -> samples.getOrNull(idx) }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                TacticalCard(borderColor = metrics.quality.color.copy(alpha = 0.45f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Real-Time Latency Graph",
                                style = MaterialTheme.typography.titleLarge
                            )
                            Text(
                                text = "${metrics.activeMethod.displayName} → ${metrics.targetDisplay}",
                                style = MaterialTheme.typography.labelSmall.copy(color = CyberCyan)
                            )
                        }
                        StatusBadgePill(
                            quality = metrics.quality,
                            isMonitoring = metrics.isMonitoring,
                            isPaused = metrics.isPaused || metrics.isScreenOffPaused
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = showJitter,
                            onClick = { showJitter = !showJitter },
                            label = { Text("Jitter Curve") },
                            modifier = Modifier.testTag("graph_toggle_jitter")
                        )
                        FilterChip(
                            selected = showThresholds,
                            onClick = { showThresholds = !showThresholds },
                            label = { Text("Threshold Bands") },
                            modifier = Modifier.testTag("graph_toggle_thresholds")
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (samples.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "No Telemetry Stream Active",
                                    style = MaterialTheme.typography.titleMedium.copy(color = TextSecondary)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(
                                    onClick = onStartMonitoring,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = CyberCyan,
                                        contentColor = ObsidianVoid
                                    )
                                ) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Start Monitoring", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    } else {
                        AnimatedPingChart(
                            samples = samples,
                            thresholds = settings.monitoring.thresholds,
                            showJitterOverlay = showJitter,
                            showThresholds = showThresholds,
                            selectedIndex = selectedSampleIndex,
                            onSelectIndex = { idx -> selectedSampleIndex = idx },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(240.dp)
                                .testTag("live_ping_canvas_chart")
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Legend
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        LegendItem(color = CyberCyan, label = "Ping (ms)")
                        LegendItem(color = AmberUnstable, label = "Jitter (ms)")
                        LegendItem(color = EmeraldExcellent, label = "≤${settings.monitoring.thresholds.excellentMaxMs}ms")
                        LegendItem(color = CrimsonPoor, label = "Packet Loss (×)")
                    }
                }
            }

            // Inspected Sample Bar
            if (inspectedSample != null) {
                item {
                    TacticalCard(
                        borderColor = CyberCyan.copy(alpha = 0.5f),
                        containerColor = DeepSlate
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "INSPECTED SAMPLE • ${FormatUtils.formatTimeOnly(inspectedSample.timestampMs)}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = CyberCyan)
                                )
                                Text(
                                    text = if (inspectedSample.isSuccess) {
                                        "${inspectedSample.latencyMs} ms  (Jitter ${inspectedSample.jitterMs} ms) via ${inspectedSample.method.shortBadge}"
                                    } else {
                                        "FAILED • ${inspectedSample.errorMessage ?: "Packet timed out"}"
                                    },
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        color = if (inspectedSample.isSuccess) TextPrimary else CrimsonPoor
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // Summary Stats Row
            item {
                TacticalCard(containerColor = DeepSlate) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        GraphStatColumn("LIVE", metrics.livePingMs?.let { "$it ms" } ?: "--", metrics.quality.color)
                        GraphStatColumn("AVG", "${metrics.avgPingMs} ms", CyberCyan)
                        GraphStatColumn("MIN", "${metrics.minPingMs} ms", EmeraldExcellent)
                        GraphStatColumn("MAX", "${metrics.maxPingMs} ms", AmberUnstable)
                        GraphStatColumn("LOSS", String.format("%.1f%%", metrics.packetLossPercent), CrimsonPoor)
                    }
                }
            }

            // Action bar
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = if (metrics.isMonitoring) onStopMonitoring else onStartMonitoring,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("graph_start_stop_btn"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (metrics.isMonitoring) CrimsonPoor else CyberCyan,
                            contentColor = if (metrics.isMonitoring) Color.White else ObsidianVoid
                        )
                    ) {
                        Icon(
                            imageVector = if (metrics.isMonitoring) Icons.Default.Stop else Icons.Default.PlayArrow,
                            contentDescription = null
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (metrics.isMonitoring) "Stop Monitoring Session" else "Start Monitoring Session",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Recent Probe Samples
            if (samples.isNotEmpty()) {
                item {
                    Text(
                        text = "RECENT SAMPLES (TAP CHART TO INSPECT)",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                    )
                }
                items(samples.takeLast(12).reversed(), key = { it.id }) { sample ->
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = DeepSlate,
                        border = BorderStroke(1.dp, BorderSlate),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = FormatUtils.formatTimeOnly(sample.timestampMs),
                                style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                            )
                            Text(
                                text = sample.method.shortBadge,
                                style = MaterialTheme.typography.labelSmall.copy(color = CyberCyan)
                            )
                            Text(
                                text = if (sample.isSuccess) "${sample.latencyMs} ms" else "TIMEOUT",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontFamily = JetBrainsMonoFontFamily,
                                    color = if (sample.isSuccess) EmeraldExcellent else CrimsonPoor
                                )
                            )
                            Text(
                                text = "J:${sample.jitterMs}ms",
                                style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                            )
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }
}

@Composable
private fun LegendItem(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Surface(
            color = color,
            shape = RoundedCornerShape(2.dp),
            modifier = Modifier.padding(end = 5.dp)
        ) {
            Box(modifier = Modifier.padding(4.dp))
        }
        Text(text = label, style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
    }
}

@Composable
private fun GraphStatColumn(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium.copy(
                fontFamily = JetBrainsMonoFontFamily,
                color = color,
                fontWeight = FontWeight.Bold
            )
        )
    }
}
