package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.RoundedCornerShape

private val GamePingDarkColorScheme = darkColorScheme(
    primary = CyberCyan,
    onPrimary = ObsidianVoid,
    primaryContainer = CyberCyanDim.copy(alpha = 0.22f),
    onPrimaryContainer = CyberCyan,
    secondary = EmeraldExcellent,
    onSecondary = ObsidianVoid,
    secondaryContainer = EmeraldExcellent.copy(alpha = 0.16f),
    onSecondaryContainer = EmeraldExcellent,
    tertiary = CyberPurple,
    onTertiary = TextPrimary,
    tertiaryContainer = CyberPurple.copy(alpha = 0.18f),
    onTertiaryContainer = CyberPurple,
    background = ObsidianVoid,
    onBackground = TextPrimary,
    surface = DeepSlate,
    onSurface = TextPrimary,
    surfaceVariant = ElevatedSlate,
    onSurfaceVariant = TextSecondary,
    surfaceContainerLowest = ObsidianVoid,
    surfaceContainerLow = DeepSlate,
    surfaceContainer = ElevatedSlate,
    surfaceContainerHigh = CardSlateHighlight,
    outline = BorderSlate,
    outlineVariant = BorderSlate.copy(alpha = 0.6f),
    error = CrimsonPoor,
    onError = TextPrimary,
    errorContainer = CrimsonPoor.copy(alpha = 0.18f),
    onErrorContainer = CrimsonPoor
)

val GamePingShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(26.dp)
)

@Composable
fun GamePingTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = GamePingDarkColorScheme,
        typography = GamePingTypography,
        shapes = GamePingShapes,
        content = content
    )
}
