package com.example.ui.navigation

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ShowChart
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.ShowChart
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.AboutScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.LiveMonitorScreen
import com.example.ui.screens.NetworkHistoryScreen
import com.example.ui.screens.OverlaySettingsScreen
import com.example.ui.screens.PingGraphScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DeepSlate
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainViewModel
import kotlinx.serialization.Serializable

@Serializable data object DashboardRoute
@Serializable data object PingGraphRoute
@Serializable data object OverlaySettingsRoute
@Serializable data object NetworkHistoryRoute
@Serializable data object LiveMonitorRoute
@Serializable data object SettingsRoute
@Serializable data object AboutRoute

private data class TopLevelDestination(
    val route: Any,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GamePingAppRoot(viewModel: MainViewModel) {
    val context = LocalContext.current
    val navController = rememberNavController()

    val metrics by viewModel.metrics.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val sessions by viewModel.sessions.collectAsStateWithLifecycle()
    val hasOverlayPermission by viewModel.hasOverlayPermission.collectAsStateWithLifecycle()
    val isBatteryOptimizationIgnored by viewModel.isBatteryOptimizationIgnored.collectAsStateWithLifecycle()
    val diagnosticSamples by viewModel.diagnosticSamples.collectAsStateWithLifecycle()
    val runningDiagnostic by viewModel.runningDiagnostic.collectAsStateWithLifecycle()

    var hasNotificationPermission by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
        )
    }

    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasNotificationPermission = granted
    }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        viewModel.refreshSystemStates()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            hasNotificationPermission = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    val requestNotificationIfNeeded = {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasNotificationPermission) {
            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val openOverlayPermissionSettings = {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        ).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
            val fallback = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(fallback)
        }
    }

    val openBatteryOptimizationSettings = {
        val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
            val fallback = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:${context.packageName}")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(fallback)
        }
    }

    val topDestinations = remember {
        listOf(
            TopLevelDestination(
                route = DashboardRoute,
                label = "Home",
                selectedIcon = Icons.Filled.Dashboard,
                unselectedIcon = Icons.Outlined.Dashboard,
                testTag = "nav_home"
            ),
            TopLevelDestination(
                route = PingGraphRoute,
                label = "Graph",
                selectedIcon = Icons.AutoMirrored.Filled.ShowChart,
                unselectedIcon = Icons.Outlined.ShowChart,
                testTag = "nav_graph"
            ),
            TopLevelDestination(
                route = OverlaySettingsRoute,
                label = "Overlay",
                selectedIcon = Icons.Filled.Layers,
                unselectedIcon = Icons.Outlined.Layers,
                testTag = "nav_overlay"
            ),
            TopLevelDestination(
                route = NetworkHistoryRoute,
                label = "History",
                selectedIcon = Icons.Filled.History,
                unselectedIcon = Icons.Outlined.History,
                testTag = "nav_history"
            )
        )
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDest = navBackStackEntry?.destination

    val isTopLevel = currentDest == null ||
        currentDest.hasRoute(DashboardRoute::class) ||
        currentDest.hasRoute(PingGraphRoute::class) ||
        currentDest.hasRoute(OverlaySettingsRoute::class) ||
        currentDest.hasRoute(NetworkHistoryRoute::class)

    val screenTitle = when {
        currentDest?.hasRoute(PingGraphRoute::class) == true -> "Ping Graph"
        currentDest?.hasRoute(OverlaySettingsRoute::class) == true -> "Floating Overlay"
        currentDest?.hasRoute(NetworkHistoryRoute::class) == true -> "Network History"
        currentDest?.hasRoute(LiveMonitorRoute::class) == true -> "Live Network Monitor"
        currentDest?.hasRoute(SettingsRoute::class) == true -> "Customization & Engine"
        currentDest?.hasRoute(AboutRoute::class) == true -> "About GamePing"
        else -> "GamePing Monitor"
    }

    val navigateToTopLevel: (Any) -> Unit = { route ->
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            containerColor = ObsidianVoid,
            contentWindowInsets = WindowInsets.safeDrawing,
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = screenTitle,
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                    },
                    navigationIcon = {
                        if (!isTopLevel) {
                            IconButton(
                                onClick = { navController.popBackStack() },
                                modifier = Modifier.testTag("top_bar_back")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Navigate back"
                                )
                            }
                        }
                    },
                    actions = {
                        IconButton(
                            onClick = { navController.navigate(LiveMonitorRoute) { launchSingleTop = true } },
                            modifier = Modifier.testTag("top_bar_live_monitor")
                        ) {
                            Icon(
                                imageVector = Icons.Default.NetworkCheck,
                                contentDescription = "Live Network Monitor",
                                tint = CyberCyan
                            )
                        }
                        IconButton(
                            onClick = { navController.navigate(SettingsRoute) { launchSingleTop = true } },
                            modifier = Modifier.testTag("top_bar_settings")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Engine Settings",
                                tint = TextPrimary
                            )
                        }
                        IconButton(
                            onClick = { navController.navigate(AboutRoute) { launchSingleTop = true } },
                            modifier = Modifier.testTag("top_bar_about")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = "About Application",
                                tint = TextSecondary
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = ObsidianVoid,
                        titleContentColor = TextPrimary
                    )
                )
            },
            bottomBar = {
                if (!useRail && isTopLevel) {
                    NavigationBar(
                        containerColor = DeepSlate,
                        tonalElevation = 0.dp
                    ) {
                        topDestinations.forEach { dest ->
                            val selected = currentDest?.hasRoute(dest.route::class) == true
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateToTopLevel(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = dest.label
                                    )
                                },
                                label = { Text(dest.label) },
                                modifier = Modifier.testTag(dest.testTag),
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = CyberCyan,
                                    selectedTextColor = CyberCyan,
                                    indicatorColor = CyberCyan.copy(alpha = 0.14f),
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                )
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail && isTopLevel) {
                    NavigationRail(
                        containerColor = DeepSlate
                    ) {
                        Spacer(modifier = Modifier.weight(0.15f))
                        topDestinations.forEach { dest ->
                            val selected = currentDest?.hasRoute(dest.route::class) == true
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateToTopLevel(dest.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = dest.label
                                    )
                                },
                                label = { Text(dest.label) },
                                modifier = Modifier.testTag(dest.testTag),
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = CyberCyan,
                                    selectedTextColor = CyberCyan,
                                    indicatorColor = CyberCyan.copy(alpha = 0.14f),
                                    unselectedIconColor = TextSecondary,
                                    unselectedTextColor = TextSecondary
                                )
                            )
                        }
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = DashboardRoute,
                    modifier = Modifier.weight(1f)
                ) {
                    composable<DashboardRoute> {
                        DashboardScreen(
                            metrics = metrics,
                            settings = settings,
                            hasOverlayPermission = hasOverlayPermission,
                            onStartMonitoring = {
                                requestNotificationIfNeeded()
                                viewModel.startMonitoring()
                            },
                            onStopMonitoring = { viewModel.stopMonitoring() },
                            onTogglePause = { viewModel.togglePause() },
                            onToggleOverlay = { enabled ->
                                requestNotificationIfNeeded()
                                viewModel.toggleOverlay(enabled)
                            },
                            onRequestOverlayPermission = openOverlayPermissionSettings,
                            onOpenGraph = { navigateToTopLevel(PingGraphRoute) },
                            onOpenLiveMonitor = {
                                navController.navigate(LiveMonitorRoute) { launchSingleTop = true }
                            },
                            onOpenSettings = {
                                navController.navigate(SettingsRoute) { launchSingleTop = true }
                            },
                            onOpenAbout = {
                                navController.navigate(AboutRoute) { launchSingleTop = true }
                            }
                        )
                    }

                    composable<PingGraphRoute> {
                        PingGraphScreen(
                            metrics = metrics,
                            settings = settings,
                            onStartMonitoring = {
                                requestNotificationIfNeeded()
                                viewModel.startMonitoring()
                            },
                            onStopMonitoring = { viewModel.stopMonitoring() }
                        )
                    }

                    composable<OverlaySettingsRoute> {
                        OverlaySettingsScreen(
                            overlay = settings.overlay,
                            metrics = metrics,
                            hasOverlayPermission = hasOverlayPermission,
                            onRequestOverlayPermission = openOverlayPermissionSettings,
                            onToggleOverlay = { enabled ->
                                requestNotificationIfNeeded()
                                viewModel.toggleOverlay(enabled)
                            },
                            onUpdateOverlay = { transform -> viewModel.updateOverlaySettings(transform) }
                        )
                    }

                    composable<NetworkHistoryRoute> {
                        NetworkHistoryScreen(
                            sessions = sessions,
                            observeEventsForSession = { id -> viewModel.observeEventsForSession(id) },
                            onDeleteSession = { id -> viewModel.deleteSession(id) },
                            onClearAll = { viewModel.clearAllHistory() }
                        )
                    }

                    composable<LiveMonitorRoute> {
                        LiveMonitorScreen(
                            metrics = metrics,
                            monitoringSettings = settings.monitoring,
                            diagnosticSamples = diagnosticSamples,
                            runningDiagnostic = runningDiagnostic,
                            onRunDiagnostic = { method -> viewModel.runDiagnostic(method) },
                            onRunAllDiagnostics = { viewModel.runAllDiagnostics() }
                        )
                    }

                    composable<SettingsRoute> {
                        SettingsScreen(
                            monitoring = settings.monitoring,
                            isBatteryOptimizationIgnored = isBatteryOptimizationIgnored,
                            hasNotificationPermission = hasNotificationPermission,
                            onUpdateMonitoring = { transform -> viewModel.updateMonitoringSettings(transform) },
                            onOpenBatterySettings = openBatteryOptimizationSettings,
                            onRequestNotificationPermission = requestNotificationIfNeeded
                        )
                    }

                    composable<AboutRoute> {
                        AboutScreen()
                    }
                }
            }
        }
    }
}
