package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Tactical Dark Palette
val ObsidianVoid = Color(0xFF070B14)
val DeepSlate = Color(0xFF0E1525)
val ElevatedSlate = Color(0xFF151E32)
val CardSlateHighlight = Color(0xFF1C2740)
val BorderSlate = Color(0xFF23304C)

// Brand & Accent Colors
val CyberCyan = Color(0xFF00E5FF)
val CyberCyanDim = Color(0xFF0099B8)
val CyberPurple = Color(0xFFA855F7)

// Network Quality Status Colors
val EmeraldExcellent = Color(0xFF00FF9D)
val CyanGood = Color(0xFF00E5FF)
val AmberUnstable = Color(0xFFFFB300)
val CrimsonPoor = Color(0xFFFF3B5C)
val OfflineGray = Color(0xFF6B7280)

// Text Hierarchy
val TextPrimary = Color(0xFFF3F7FF)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
