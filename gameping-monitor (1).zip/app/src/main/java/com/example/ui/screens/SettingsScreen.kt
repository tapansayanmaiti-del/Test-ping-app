package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.preferences.MonitoringSettings
import com.example.domain.model.ProbeMethod
import com.example.domain.model.TestServerPreset
import com.example.ui.components.TacticalCard
import com.example.ui.theme.AmberUnstable
import com.example.ui.theme.CrimsonPoor
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.EmeraldExcellent
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
    monitoring: MonitoringSettings,
    isBatteryOptimizationIgnored: Boolean,
    hasNotificationPermission: Boolean,
    onUpdateMonitoring: ((MonitoringSettings) -> MonitoringSettings) -> Unit,
    onOpenBatterySettings: () -> Unit,
    onRequestNotificationPermission: () -> Unit,
    modifier: Modifier = Modifier
) {
    var customHostInput by remember(monitoring.customHost) { mutableStateOf(monitoring.customHost) }
    var customPortInput by remember(monitoring.customPort) { mutableStateOf(monitoring.customPort.toString()) }
    var customHttpsInput by remember(monitoring.customHttpsUrl) { mutableStateOf(monitoring.customHttpsUrl) }

    val intervals = listOf(500L to "500ms (Esports)", 1000L to "1000ms (Balanced)", 2000L to "2000ms (Saver)", 5000L to "5000ms (Eco)")

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Primary Probe Protocol
            item {
                TacticalCard {
                    Text("Primary Measurement Technique", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = monitoring.probeMethod.description,
                        style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ProbeMethod.entries.forEach { method ->
                            FilterChip(
                                selected = monitoring.probeMethod == method,
                                onClick = {
                                    onUpdateMonitoring { it.copy(probeMethod = method) }
                                },
                                label = { Text(method.displayName) },
                                modifier = Modifier.testTag("probe_method_${method.name.lowercase()}")
                            )
                        }
                    }
                }
            }

            // 2. Sampling Interval
            item {
                TacticalCard {
                    Text("Sampling Interval", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Longer intervals minimize CPU wakeups and battery drain during extended sessions.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        intervals.forEach { (ms, label) ->
                            FilterChip(
                                selected = monitoring.probeIntervalMs == ms,
                                onClick = {
                                    onUpdateMonitoring { it.copy(probeIntervalMs = ms) }
                                },
                                label = { Text(label) }
                            )
                        }
                    }
                }
            }

            // 3. Test Server Selector + Custom Host
            item {
                TacticalCard {
                    Text("Benchmark Test Server", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Select an edge server to estimate network latency, or configure your own host.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TestServerPreset.entries.forEach { preset ->
                            FilterChip(
                                selected = monitoring.serverPreset == preset,
                                onClick = {
                                    onUpdateMonitoring { it.copy(serverPreset = preset) }
                                },
                                label = { Text(preset.label) }
                            )
                        }
                    }

                    if (monitoring.serverPreset == TestServerPreset.CUSTOM) {
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = customHostInput,
                            onValueChange = { customHostInput = it },
                            label = { Text("Host or IP Address") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = customPortInput,
                            onValueChange = { customPortInput = it.filter { ch -> ch.isDigit() } },
                            label = { Text("TCP Port (e.g., 443)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = customHttpsInput,
                            onValueChange = { customHttpsInput = it },
                            label = { Text("HTTPS Endpoint URL") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = {
                                val parsedPort = customPortInput.toIntOrNull()?.coerceIn(1, 65535) ?: 443
                                onUpdateMonitoring {
                                    it.copy(
                                        customHost = customHostInput.trim().ifBlank { "1.1.1.1" },
                                        customPort = parsedPort,
                                        customHttpsUrl = customHttpsInput.trim().ifBlank { "https://1.1.1.1/cdn-cgi/trace" }
                                    )
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyberCyan,
                                contentColor = ObsidianVoid
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Save Custom Server", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // 4. Customizable Latency Stability Thresholds
            item {
                val th = monitoring.thresholds
                TacticalCard {
                    Text("Network Quality Thresholds", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(10.dp))

                    ThresholdSlider(
                        label = "Excellent (Green) Max Ping",
                        valueText = "≤ ${th.excellentMaxMs} ms",
                        value = th.excellentMaxMs.toFloat(),
                        range = 15f..80f,
                        accent = EmeraldExcellent,
                        onValueChange = { v ->
                            val newExcellent = v.roundToInt()
                            onUpdateMonitoring {
                                it.copy(
                                    thresholds = th.copy(
                                        excellentMaxMs = newExcellent,
                                        goodMaxMs = maxOf(th.goodMaxMs, newExcellent + 10)
                                    )
                                )
                            }
                        }
                    )

                    ThresholdSlider(
                        label = "Good (Blue) Max Ping",
                        valueText = "≤ ${th.goodMaxMs} ms",
                        value = th.goodMaxMs.toFloat(),
                        range = 40f..150f,
                        accent = CyberCyan,
                        onValueChange = { v ->
                            val newGood = v.roundToInt()
                            onUpdateMonitoring {
                                it.copy(
                                    thresholds = th.copy(
                                        goodMaxMs = newGood,
                                        unstableMaxMs = maxOf(th.unstableMaxMs, newGood + 20)
                                    )
                                )
                            }
                        }
                    )

                    ThresholdSlider(
                        label = "Unstable (Yellow) Max Ping",
                        valueText = "≤ ${th.unstableMaxMs} ms",
                        value = th.unstableMaxMs.toFloat(),
                        range = 80f..300f,
                        accent = AmberUnstable,
                        onValueChange = { v ->
                            onUpdateMonitoring {
                                it.copy(thresholds = th.copy(unstableMaxMs = v.roundToInt()))
                            }
                        }
                    )

                    ThresholdSlider(
                        label = "Jitter Warning Threshold",
                        valueText = "> ${th.jitterWarningMs} ms",
                        value = th.jitterWarningMs.toFloat(),
                        range = 5f..80f,
                        accent = AmberUnstable,
                        onValueChange = { v ->
                            onUpdateMonitoring {
                                it.copy(thresholds = th.copy(jitterWarningMs = v.roundToInt()))
                            }
                        }
                    )

                    ThresholdSlider(
                        label = "Packet Loss Warning",
                        valueText = "> ${String.format("%.1f", th.packetLossWarningPercent)}%",
                        value = th.packetLossWarningPercent,
                        range = 0.5f..15f,
                        accent = CrimsonPoor,
                        onValueChange = { v ->
                            onUpdateMonitoring {
                                it.copy(thresholds = th.copy(packetLossWarningPercent = v))
                            }
                        }
                    )
                }
            }

            // 5. Battery & Permissions Management
            item {
                TacticalCard {
                    Text("Battery & System Compliance", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(8.dp))

                    SwitchSettingRow(
                        title = "Auto-Pause on Screen Off",
                        subtitle = "Reduces battery & network drain when screen locks",
                        checked = monitoring.pauseWhenScreenOff,
                        onCheckedChange = { checked ->
                            onUpdateMonitoring { it.copy(pauseWhenScreenOff = checked) }
                        }
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f).padding(end = 10.dp)) {
                            Text("Battery Optimization", style = MaterialTheme.typography.bodyLarge)
                            Text(
                                text = if (isBatteryOptimizationIgnored) {
                                    "Unrestricted — background service stays active during long matches."
                                } else {
                                    "Optimized by Android — OEMs may throttle background pings during long games."
                                },
                                style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                            )
                        }
                        OutlinedButton(
                            onClick = onOpenBatterySettings,
                            modifier = Modifier.testTag("open_battery_settings_btn")
                        ) {
                            Icon(Icons.Default.BatteryChargingFull, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isBatteryOptimizationIgnored) "Enabled" else "Configure")
                        }
                    }

                    if (!hasNotificationPermission) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = onRequestNotificationPermission,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AmberUnstable,
                                contentColor = ObsidianVoid
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Notifications, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Allow Monitoring Notification", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }
}

@Composable
private fun ThresholdSlider(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    accent: androidx.compose.ui.graphics.Color,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, style = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary))
            Text(
                text = valueText,
                style = MaterialTheme.typography.labelMedium.copy(color = accent, fontWeight = FontWeight.Bold)
            )
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = onValueChange,
            valueRange = range,
            colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent)
        )
    }
}
