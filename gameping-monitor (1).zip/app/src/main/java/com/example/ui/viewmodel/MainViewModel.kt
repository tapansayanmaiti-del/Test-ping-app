package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.os.PowerManager
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.GamePingApplication
import com.example.data.local.NetworkEventEntity
import com.example.data.local.NetworkSessionEntity
import com.example.data.preferences.AppSettings
import com.example.data.preferences.MonitoringSettings
import com.example.data.preferences.OverlaySettings
import com.example.domain.model.NetworkMetricsSnapshot
import com.example.domain.model.ProbeMethod
import com.example.domain.model.ProbeSample
import com.example.service.NetworkMonitorService
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as GamePingApplication
    private val controller = app.monitorController
    private val settingsRepo = app.settingsRepository
    private val historyRepo = app.historyRepository

    val metrics: StateFlow<NetworkMetricsSnapshot> = controller.metrics

    val settings: StateFlow<AppSettings> = settingsRepo.settingsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = AppSettings()
        )

    val sessions: StateFlow<List<NetworkSessionEntity>> = historyRepo.allSessions
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val recentPersistedEvents: StateFlow<List<NetworkEventEntity>> = historyRepo.recentEvents
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _hasOverlayPermission = MutableStateFlow(checkOverlayPermission())
    val hasOverlayPermission: StateFlow<Boolean> = _hasOverlayPermission.asStateFlow()

    private val _isBatteryOptimizationIgnored = MutableStateFlow(checkBatteryOptimizationIgnored())
    val isBatteryOptimizationIgnored: StateFlow<Boolean> = _isBatteryOptimizationIgnored.asStateFlow()

    private val _diagnosticSamples = MutableStateFlow<Map<ProbeMethod, ProbeSample>>(emptyMap())
    val diagnosticSamples: StateFlow<Map<ProbeMethod, ProbeSample>> = _diagnosticSamples.asStateFlow()

    private val _runningDiagnostic = MutableStateFlow<ProbeMethod?>(null)
    val runningDiagnostic: StateFlow<ProbeMethod?> = _runningDiagnostic.asStateFlow()

    fun refreshSystemStates() {
        _hasOverlayPermission.value = checkOverlayPermission()
        _isBatteryOptimizationIgnored.value = checkBatteryOptimizationIgnored()
        controller.connectivityObserver.refresh()
        if (settings.value.overlay.overlayEnabled && _hasOverlayPermission.value && metrics.value.isMonitoring) {
            NetworkMonitorService.syncOverlayIfActive(app)
        }
    }

    fun startMonitoring() {
        NetworkMonitorService.startMonitoring(app)
    }

    fun stopMonitoring() {
        NetworkMonitorService.stopMonitoring(app)
    }

    fun togglePause() {
        controller.togglePause()
    }

    fun toggleOverlay(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepo.setOverlayEnabled(enabled)
            if (enabled) {
                if (checkOverlayPermission()) {
                    NetworkMonitorService.showOverlay(app)
                }
            } else {
                if (metrics.value.isMonitoring) {
                    NetworkMonitorService.hideOverlay(app)
                }
            }
        }
    }

    fun updateOverlaySettings(transform: (OverlaySettings) -> OverlaySettings) {
        viewModelScope.launch {
            settingsRepo.updateOverlaySettings(transform)
        }
    }

    fun updateMonitoringSettings(transform: (MonitoringSettings) -> MonitoringSettings) {
        viewModelScope.launch {
            settingsRepo.updateMonitoringSettings(transform)
        }
    }

    fun runDiagnostic(method: ProbeMethod) {
        if (_runningDiagnostic.value != null) return
        viewModelScope.launch {
            _runningDiagnostic.value = method
            val result = controller.runSingleDiagnostic(method)
            _diagnosticSamples.update { it + (method to result) }
            _runningDiagnostic.value = null
        }
    }

    fun runAllDiagnostics() {
        if (_runningDiagnostic.value != null) return
        viewModelScope.launch {
            for (method in ProbeMethod.entries) {
                _runningDiagnostic.value = method
                val result = controller.runSingleDiagnostic(method)
                _diagnosticSamples.update { it + (method to result) }
            }
            _runningDiagnostic.value = null
        }
    }

    fun observeEventsForSession(sessionId: Long): Flow<List<NetworkEventEntity>> =
        historyRepo.observeEventsForSession(sessionId)

    fun deleteSession(sessionId: Long) {
        viewModelScope.launch {
            historyRepo.deleteSession(sessionId)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            historyRepo.clearAll()
        }
    }

    private fun checkOverlayPermission(): Boolean =
        Settings.canDrawOverlays(app)

    private fun checkBatteryOptimizationIgnored(): Boolean {
        val pm = app.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return false
        return pm.isIgnoringBatteryOptimizations(app.packageName)
    }
}
