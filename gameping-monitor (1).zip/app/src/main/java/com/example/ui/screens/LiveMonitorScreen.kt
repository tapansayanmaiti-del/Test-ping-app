package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.preferences.MonitoringSettings
import com.example.domain.model.LiveEventType
import com.example.domain.model.NetworkMetricsSnapshot
import com.example.domain.model.ProbeMethod
import com.example.domain.model.ProbeSample
import com.example.ui.components.FormatUtils
import com.example.ui.components.TacticalCard
import com.example.ui.theme.AmberUnstable
import com.example.ui.theme.BorderSlate
import com.example.ui.theme.CrimsonPoor
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DeepSlate
import com.example.ui.theme.EmeraldExcellent
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.roundToInt

@Composable
fun LiveMonitorScreen(
    metrics: NetworkMetricsSnapshot,
    monitoringSettings: MonitoringSettings,
    diagnosticSamples: Map<ProbeMethod, ProbeSample>,
    runningDiagnostic: ProbeMethod?,
    onRunDiagnostic: (ProbeMethod) -> Unit,
    onRunAllDiagnostics: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // 1. Connectivity & Transport Capabilities Inspector
            item {
                val conn = metrics.connectivity
                TacticalCard(borderColor = CyberCyan.copy(alpha = 0.35f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.NetworkCheck, contentDescription = null, tint = CyberCyan)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Active Network Transport", style = MaterialTheme.typography.titleLarge)
                        }
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = (if (conn.isInternetValidated) EmeraldExcellent else AmberUnstable).copy(alpha = 0.16f)
                        ) {
                            Text(
                                text = if (conn.isInternetValidated) "VALIDATED" else if (conn.isConnected) "UNVALIDATED" else "OFFLINE",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (conn.isInternetValidated) EmeraldExcellent else AmberUnstable,
                                    fontWeight = FontWeight.Bold
                                ),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    KeyValueRow("Transport", conn.transportDetail)
                    KeyValueRow("VPN Tunnel", if (conn.isVpnActive) "Active (adds routing overhead)" else "Not Detected")
                    KeyValueRow("Metered Link", if (conn.isMetered) "Yes (Mobile/Metered)" else "Unmetered")
                    conn.wifiFrequencyMhz?.let { KeyValueRow("Wi-Fi Band", "$it MHz") }
                    conn.wifiLinkSpeedMbps?.let { KeyValueRow("Wi-Fi Link Speed", "$it Mbps") }
                    conn.signalStrengthDbm?.let { KeyValueRow("Signal RSSI", "$it dBm") }
                    conn.linkDownstreamKbps?.let {
                        KeyValueRow("Reported Down/Up", "${it / 1000} / ${(conn.linkUpstreamKbps ?: 0) / 1000} Mbps")
                    }
                    KeyValueRow("Last DNS Resolution", metrics.lastDnsMs?.let { "$it ms" } ?: "--")
                }
            }

            // 2. Multi-Protocol Benchmark Suite (Distinguishing ICMP vs TCP vs HTTPS vs DNS)
            item {
                TacticalCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Protocol Diagnostic Suite", style = MaterialTheme.typography.titleMedium)
                            Text(
                                text = "Each probe is strictly labeled by protocol—ICMP Echo is never substituted with TCP.",
                                style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = onRunAllDiagnostics,
                            enabled = runningDiagnostic == null,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyberCyan,
                                contentColor = ObsidianVoid
                            ),
                            modifier = Modifier.testTag("run_all_diagnostics_btn")
                        ) {
                            if (runningDiagnostic != null) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    strokeWidth = 2.dp,
                                    color = ObsidianVoid
                                )
                            } else {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            }
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Test All", fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        ProbeMethod.entries.forEach { method ->
                            val sample = diagnosticSamples[method]
                            val target = when (method) {
                                ProbeMethod.TCP_CONNECT -> "${monitoringSettings.resolvedHost()}:${monitoringSettings.resolvedPort()}"
                                ProbeMethod.ICMP_ECHO -> monitoringSettings.resolvedHost()
                                ProbeMethod.HTTPS_RESPONSE -> monitoringSettings.resolvedHttpsUrl()
                                ProbeMethod.DNS_LOOKUP -> monitoringSettings.resolvedDnsHost()
                            }
                            DiagnosticMethodCard(
                                method = method,
                                target = target,
                                sample = sample,
                                isRunning = runningDiagnostic == method,
                                onRun = { onRunDiagnostic(method) }
                            )
                        }
                    }
                }
            }

            // 3. Interruption, Recovery & Spike Feed
            item {
                Text(
                    text = "INTERRUPTION & RECOVERY LOG",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                )
            }

            if (metrics.recentEvents.isEmpty()) {
                item {
                    TacticalCard(containerColor = DeepSlate) {
                        Text(
                            text = "No interruptions, recoveries, or spikes logged in the current session.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = TextMuted)
                        )
                    }
                }
            } else {
                items(metrics.recentEvents, key = { it.id }) { event ->
                    val eventColor = when (event.type) {
                        LiveEventType.INTERRUPTION -> CrimsonPoor
                        LiveEventType.RECOVERY -> EmeraldExcellent
                        LiveEventType.HIGH_LATENCY_SPIKE -> AmberUnstable
                        LiveEventType.PACKET_LOSS_BURST -> CrimsonPoor
                        LiveEventType.SESSION_STARTED -> CyberCyan
                    }
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = DeepSlate,
                        border = BorderStroke(1.dp, eventColor.copy(alpha = 0.35f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = event.title,
                                    style = MaterialTheme.typography.titleMedium.copy(color = eventColor)
                                )
                                Text(
                                    text = event.detail,
                                    style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                                )
                            }
                            Text(
                                text = FormatUtils.formatTimeOnly(event.timestampMs),
                                style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                            )
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }
}

@Composable
private fun DiagnosticMethodCard(
    method: ProbeMethod,
    target: String,
    sample: ProbeSample?,
    isRunning: Boolean,
    onRun: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = DeepSlate,
        border = BorderStroke(1.dp, BorderSlate),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(method.displayName, style = MaterialTheme.typography.titleMedium)
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = CyberCyan.copy(alpha = 0.14f)
                        ) {
                            Text(
                                text = method.shortBadge,
                                style = MaterialTheme.typography.labelSmall.copy(color = CyberCyan),
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                            )
                        }
                    }
                    Text(
                        text = target,
                        style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                    )
                }

                OutlinedButton(
                    onClick = onRun,
                    enabled = !isRunning,
                    modifier = Modifier.testTag("diag_run_${method.name.lowercase()}")
                ) {
                    if (isRunning) {
                        CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
                    } else {
                        Text("Probe")
                    }
                }
            }

            if (sample != null) {
                Spacer(modifier = Modifier.height(8.dp))
                if (sample.isSuccess) {
                    Text(
                        text = "Result: ${sample.latencyMs} ms",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontFamily = JetBrainsMonoFontFamily,
                            color = EmeraldExcellent,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    sample.breakdown?.let { b ->
                        val parts = buildList {
                            b.dnsMs?.let { add("DNS ${it.roundToInt()}ms") }
                            b.tcpMs?.let { add("TCP ${it.roundToInt()}ms") }
                            b.tlsMs?.let { add("TLS ${it.roundToInt()}ms") }
                            b.ttfbMs?.let { add("TTFB ${it.roundToInt()}ms") }
                        }
                        if (parts.isNotEmpty()) {
                            Text(
                                text = parts.joinToString(" • "),
                                style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                            )
                        }
                    }
                } else {
                    Text(
                        text = "Failed: ${sample.errorMessage ?: "Probe failed"}",
                        style = MaterialTheme.typography.labelSmall.copy(color = CrimsonPoor)
                    )
                }
            } else {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = method.description,
                    style = MaterialTheme.typography.bodyMedium.copy(color = TextMuted)
                )
            }
        }
    }
}

@Composable
private fun KeyValueRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary))
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium.copy(
                fontFamily = JetBrainsMonoFontFamily,
                color = TextPrimary
            )
        )
    }
}
