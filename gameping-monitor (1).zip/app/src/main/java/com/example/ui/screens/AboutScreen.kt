package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.R
import com.example.ui.components.TacticalCard
import com.example.ui.theme.AmberUnstable
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DeepSlate
import com.example.ui.theme.EmeraldExcellent
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun AboutScreen(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                TacticalCard(borderColor = CyberCyan.copy(alpha = 0.45f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(id = R.drawable.app_icon_pulse),
                            contentDescription = "GamePing Monitor Logo",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(56.dp)
                                .clip(RoundedCornerShape(14.dp))
                        )
                        Spacer(modifier = Modifier.width(14.dp))
                        Column {
                            Text("GamePing Monitor", style = MaterialTheme.typography.headlineMedium)
                            Text(
                                text = "v${BuildConfig.VERSION_NAME} • Real-Time Network HUD",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = JetBrainsMonoFontFamily,
                                    color = CyberCyan
                                )
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Built with Kotlin, Jetpack Compose, Material 3, Android Foreground Service, WindowManager Overlay, ConnectivityManager, OkHttp, Room, and DataStore.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                    )
                }
            }

            item {
                InfoSectionCard(
                    title = "Technical Limitations & Transparency",
                    icon = Icons.Default.WarningAmber,
                    accent = AmberUnstable,
                    bullets = listOf(
                        "GamePing Monitor measures independent latency to configurable edge/test servers (such as 1.1.1.1 or 8.8.8.8) rather than reading the internal ping inside a third-party game.",
                        "Android sandboxing prevents apps from inspecting another game's private sockets or server IP addresses without VPN/root interception.",
                        "External test-server ping can differ from a game's actual match server due to regional server placement and ISP peering routes.",
                        "ICMP Echo uses /system/bin/ping when permitted by the device kernel/network; if ICMP is blocked, errors are reported explicitly and never disguised as TCP latency."
                    )
                )
            }

            item {
                InfoSectionCard(
                    title = "Measurement Techniques Explained",
                    icon = Icons.Default.Info,
                    accent = CyberCyan,
                    bullets = listOf(
                        "TCP Connect: Measures exact SYN → SYN-ACK socket handshake RTT to the target host and port.",
                        "ICMP Echo: Measures raw ICMP Echo Request/Reply round-trip time via system ping.",
                        "HTTPS Response: Measures full HTTP/TLS endpoint response latency (DNS + TCP + TLS + TTFB) using OkHttp.",
                        "DNS Lookup: Measures hostname resolution latency via the active system DNS resolver."
                    )
                )
            }

            item {
                InfoSectionCard(
                    title = "Android Overlay & Background Compliance",
                    icon = Icons.Default.Security,
                    accent = EmeraldExcellent,
                    bullets = listOf(
                        "Uses TYPE_APPLICATION_OVERLAY with FLAG_NOT_FOCUSABLE so touches outside the HUD pass cleanly to your game.",
                        "Supports Touch-Through Lock mode so accidental taps on the widget never interrupt game controls.",
                        "Runs as a compliant specialUse Foreground Service with a low-priority notification and optional screen-off auto-pause."
                    )
                )
            }

            item {
                InfoSectionCard(
                    title = "APK Download & Device Testing Guide",
                    icon = Icons.Default.Build,
                    accent = CyberCyan,
                    bullets = listOf(
                        "Get the APK: Open Google AI Studio Settings / Export → Generate APK / AAB to download the installable package, or build locally with 'gradle :app:assembleDebug'.",
                        "Sideload on Android: Open the downloaded .apk on your device and allow 'Install unknown apps' if prompted.",
                        "1. Grant 'Display over other apps' permission on the Overlay tab.",
                        "2. Start monitoring from Dashboard and launch any mobile game or app to confirm the floating HUD stays visible and draggable.",
                        "3. Toggle 'Lock Touch Pass-Through' in Overlay Settings so game touches pass through the widget, and toggle Wi-Fi / Mobile Data to verify Interruption & Recovery logging."
                    )
                )
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }
}

@Composable
private fun InfoSectionCard(
    title: String,
    icon: ImageVector,
    accent: Color,
    bullets: List<String>
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = DeepSlate,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.35f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = icon, contentDescription = null, tint = accent)
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = title, style = MaterialTheme.typography.titleMedium)
            }
            Spacer(modifier = Modifier.height(10.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                bullets.forEach { bullet ->
                    Text(
                        text = "• $bullet",
                        style = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary)
                    )
                }
            }
        }
    }
}
