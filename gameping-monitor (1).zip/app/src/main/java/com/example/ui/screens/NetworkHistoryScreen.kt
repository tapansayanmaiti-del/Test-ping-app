package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.local.NetworkEventEntity
import com.example.data.local.NetworkSessionEntity
import com.example.ui.components.FormatUtils
import com.example.ui.components.TacticalCard
import com.example.ui.theme.AmberUnstable
import com.example.ui.theme.BorderSlate
import com.example.ui.theme.CrimsonPoor
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DeepSlate
import com.example.ui.theme.EmeraldExcellent
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.OfflineGray
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.flow.Flow

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NetworkHistoryScreen(
    sessions: List<NetworkSessionEntity>,
    observeEventsForSession: (Long) -> Flow<List<NetworkEventEntity>>,
    onDeleteSession: (Long) -> Unit,
    onClearAll: () -> Unit,
    modifier: Modifier = Modifier
) {
    var filterConn by remember { mutableStateOf("All") }
    var selectedSession by remember { mutableStateOf<NetworkSessionEntity?>(null) }
    var showClearDialog by remember { mutableStateOf(false) }

    val filteredSessions = remember(sessions, filterConn) {
        if (filterConn == "All") sessions
        else sessions.filter { it.connectionType.contains(filterConn, ignoreCase = true) }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Network Session History", style = MaterialTheme.typography.titleLarge)
                        Text(
                            text = "${sessions.size} recorded gaming telemetry sessions",
                            style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                        )
                    }
                    if (sessions.isNotEmpty()) {
                        IconButton(
                            onClick = { showClearDialog = true },
                            modifier = Modifier.testTag("clear_history_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteSweep,
                                contentDescription = "Clear all history",
                                tint = CrimsonPoor
                            )
                        }
                    }
                }
            }

            if (sessions.isNotEmpty()) {
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("All", "Wi-Fi", "Mobile", "Ethernet").forEach { filter ->
                            FilterChip(
                                selected = filterConn == filter,
                                onClick = { filterConn = filter },
                                label = { Text(filter) }
                            )
                        }
                    }
                }
            }

            if (filteredSessions.isEmpty()) {
                item {
                    TacticalCard(containerColor = DeepSlate) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.img_empty_history),
                                contentDescription = "No recorded sessions yet",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(170.dp)
                                    .clip(RoundedCornerShape(12.dp))
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Text(
                                text = "No Recorded Sessions Yet",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Start monitoring from the Dashboard to record ping averages, jitter, packet loss, and connection interruptions.",
                                style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                            )
                        }
                    }
                }
            } else {
                items(filteredSessions, key = { it.id }) { session ->
                    SessionHistoryCard(
                        session = session,
                        onClick = { selectedSession = session },
                        onDelete = { onDeleteSession(session.id) }
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }

    selectedSession?.let { session ->
        val events by observeEventsForSession(session.id).collectAsStateWithLifecycle(initialValue = emptyList())
        ModalBottomSheet(
            onDismissRequest = { selectedSession = null },
            containerColor = DeepSlate
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Session #${session.id} Details",
                    style = MaterialTheme.typography.titleLarge
                )
                Text(
                    text = "${FormatUtils.formatDateTime(session.startTimeMs)} • ${FormatUtils.formatDuration(session.durationSec)}",
                    style = MaterialTheme.typography.labelSmall.copy(color = CyberCyan)
                )
                Text(
                    text = "${session.probeMethod} → ${session.targetHost} (${session.connectionType})",
                    style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                )

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFF0A101E),
                    border = BorderStroke(1.dp, BorderSlate),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        HistoryStat("AVG", "${session.avgPingMs}ms", CyberCyan)
                        HistoryStat("MIN", "${session.minPingMs}ms", EmeraldExcellent)
                        HistoryStat("MAX", "${session.maxPingMs}ms", AmberUnstable)
                        HistoryStat("JITTER", "${session.avgJitterMs}ms", TextPrimary)
                        HistoryStat("LOSS", String.format("%.1f%%", session.packetLossPercent), CrimsonPoor)
                    }
                }

                HorizontalDivider(color = BorderSlate)

                Text(
                    text = "EVENTS & INTERRUPTIONS (${events.size})",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                )

                if (events.isEmpty()) {
                    Text(
                        text = "No interruptions or latency spikes recorded in this session.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = TextMuted)
                    )
                } else {
                    events.take(15).forEach { event ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(event.title, style = MaterialTheme.typography.bodyMedium.copy(color = TextPrimary))
                                Text(event.detail, style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
                            }
                            Text(
                                text = FormatUtils.formatTimeOnly(event.timestampMs),
                                style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = { Text("Clear Network History?") },
            text = { Text("This deletes all recorded monitoring sessions and interruption logs from local storage.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        onClearAll()
                        showClearDialog = false
                    }
                ) {
                    Text("Clear All", color = CrimsonPoor)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun SessionHistoryCard(
    session: NetworkSessionEntity,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    val qualityColor = when (session.qualityLabel) {
        "Excellent" -> EmeraldExcellent
        "Good" -> CyberCyan
        "Unstable" -> AmberUnstable
        "Poor" -> CrimsonPoor
        else -> OfflineGray
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .testTag("history_session_card_${session.id}"),
        shape = RoundedCornerShape(14.dp),
        color = DeepSlate,
        border = BorderStroke(1.dp, BorderSlate)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = qualityColor.copy(alpha = 0.16f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = session.qualityLabel.uppercase(),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = qualityColor,
                                    fontWeight = FontWeight.Bold
                                ),
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = session.connectionType,
                            style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                        )
                    }
                    Spacer(modifier = Modifier.height(5.dp))
                    Text(
                        text = "${session.probeMethod} → ${session.targetHost}",
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "${FormatUtils.formatDateTime(session.startTimeMs)} • ${FormatUtils.formatDuration(session.durationSec)}",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                    )
                }
                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete session",
                        tint = TextMuted
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                HistoryStat("AVG", "${session.avgPingMs}ms", CyberCyan)
                HistoryStat("MIN/MAX", "${session.minPingMs}/${session.maxPingMs}", TextPrimary)
                HistoryStat("JITTER", "${session.avgJitterMs}ms", AmberUnstable)
                HistoryStat("LOSS", String.format("%.1f%%", session.packetLossPercent), CrimsonPoor)
                HistoryStat("PROBES", "${session.totalProbes}", TextSecondary)
            }
        }
    }
}

@Composable
private fun HistoryStat(label: String, value: String, color: Color) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelSmall.copy(color = TextMuted))
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium.copy(
                fontFamily = JetBrainsMonoFontFamily,
                color = color,
                fontWeight = FontWeight.Bold
            )
        )
    }
}
