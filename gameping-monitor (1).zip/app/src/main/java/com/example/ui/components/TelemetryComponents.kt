package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.model.NetworkQuality
import com.example.domain.model.NetworkThresholds
import com.example.domain.model.ProbeSample
import com.example.ui.theme.AmberUnstable
import com.example.ui.theme.BorderSlate
import com.example.ui.theme.CrimsonPoor
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DeepSlate
import com.example.ui.theme.ElevatedSlate
import com.example.ui.theme.EmeraldExcellent
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

@Composable
fun TacticalCard(
    modifier: Modifier = Modifier,
    borderColor: Color = BorderSlate,
    containerColor: Color = ElevatedSlate,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = containerColor,
        border = BorderStroke(1.dp, borderColor),
        tonalElevation = 2.dp
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            content = content
        )
    }
}

@Composable
fun StatusBadgePill(
    quality: NetworkQuality,
    isMonitoring: Boolean,
    isPaused: Boolean,
    modifier: Modifier = Modifier
) {
    val activeColor by animateColorAsState(
        targetValue = when {
            !isMonitoring -> TextMuted
            isPaused -> AmberUnstable
            else -> quality.color
        },
        animationSpec = tween(250),
        label = "statusColor"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(850),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    val label = when {
        !isMonitoring -> "STANDBY"
        isPaused -> "PAUSED"
        else -> quality.shortStatus
    }

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(999.dp),
        color = activeColor.copy(alpha = 0.14f),
        border = BorderStroke(1.dp, activeColor.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(
                        activeColor.copy(
                            alpha = if (isMonitoring && !isPaused) pulseAlpha else 1f
                        )
                    )
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = activeColor
                )
            )
        }
    }
}

@Composable
fun MetricTile(
    label: String,
    value: String,
    unit: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    TacticalCard(
        modifier = modifier,
        borderColor = accentColor.copy(alpha = 0.28f),
        containerColor = DeepSlate
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = accentColor,
                modifier = Modifier.size(16.dp)
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                text = value,
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontFamily = JetBrainsMonoFontFamily,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
            )
            if (unit.isNotEmpty()) {
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = unit,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TextMuted
                    ),
                    modifier = Modifier.padding(bottom = 3.dp)
                )
            }
        }
    }
}

@Composable
fun AnimatedPingChart(
    samples: List<ProbeSample>,
    thresholds: NetworkThresholds,
    showJitterOverlay: Boolean,
    showThresholds: Boolean,
    selectedIndex: Int? = null,
    onSelectIndex: ((Int?) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val maxLatency = max(
        thresholds.unstableMaxMs + 40,
        (samples.mapNotNull { it.latencyMs }.maxOrNull() ?: 100) + 20
    ).toFloat()

    Box(modifier = modifier) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(samples.size) {
                    if (onSelectIndex != null && samples.isNotEmpty()) {
                        detectTapGestures { offset ->
                            val stepX = if (samples.size > 1) {
                                size.width.toFloat() / (samples.size - 1)
                            } else {
                                size.width.toFloat()
                            }
                            val idx = (offset.x / stepX).roundToInt().coerceIn(0, samples.lastIndex)
                            onSelectIndex(idx)
                        }
                    }
                }
        ) {
            val w = size.width
            val h = size.height
            val padTop = 10f
            val padBottom = 14f
            val chartH = (h - padTop - padBottom).coerceAtLeast(10f)

            fun yForMs(ms: Float): Float {
                val ratio = (ms / maxLatency).coerceIn(0f, 1f)
                return padTop + chartH * (1f - ratio)
            }

            // Grid lines
            for (frac in listOf(0.25f, 0.5f, 0.75f)) {
                val y = padTop + chartH * frac
                drawLine(
                    color = BorderSlate.copy(alpha = 0.45f),
                    start = Offset(0f, y),
                    end = Offset(w, y),
                    strokeWidth = 1.5f
                )
            }

            // Threshold dashed lines
            if (showThresholds) {
                val dash = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                val greenY = yForMs(thresholds.excellentMaxMs.toFloat())
                val yellowY = yForMs(thresholds.goodMaxMs.toFloat())
                val redY = yForMs(thresholds.unstableMaxMs.toFloat())

                drawLine(
                    color = EmeraldExcellent.copy(alpha = 0.4f),
                    start = Offset(0f, greenY),
                    end = Offset(w, greenY),
                    strokeWidth = 2f,
                    pathEffect = dash
                )
                drawLine(
                    color = AmberUnstable.copy(alpha = 0.4f),
                    start = Offset(0f, yellowY),
                    end = Offset(w, yellowY),
                    strokeWidth = 2f,
                    pathEffect = dash
                )
                drawLine(
                    color = CrimsonPoor.copy(alpha = 0.4f),
                    start = Offset(0f, redY),
                    end = Offset(w, redY),
                    strokeWidth = 2f,
                    pathEffect = dash
                )
            }

            if (samples.isEmpty()) return@Canvas

            val stepX = if (samples.size > 1) w / (samples.size - 1).toFloat() else w / 2f

            // Build latency line & gradient fill
            val linePath = Path()
            val fillPath = Path()
            var hasStarted = false
            var lastX = 0f

            samples.forEachIndexed { index, sample ->
                val x = if (samples.size == 1) w / 2f else index * stepX
                val ms = sample.latencyMs?.toFloat()
                if (ms != null) {
                    val y = yForMs(ms)
                    if (!hasStarted) {
                        linePath.moveTo(x, y)
                        fillPath.moveTo(x, padTop + chartH)
                        fillPath.lineTo(x, y)
                        hasStarted = true
                    } else {
                        linePath.lineTo(x, y)
                        fillPath.lineTo(x, y)
                    }
                    lastX = x
                }
            }

            if (hasStarted) {
                fillPath.lineTo(lastX, padTop + chartH)
                fillPath.close()

                drawPath(
                    path = fillPath,
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            CyberCyan.copy(alpha = 0.30f),
                            CyberCyan.copy(alpha = 0.0f)
                        ),
                        startY = padTop,
                        endY = padTop + chartH
                    )
                )

                drawPath(
                    path = linePath,
                    color = CyberCyan,
                    style = Stroke(width = 4f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
            }

            // Optional jitter line
            if (showJitterOverlay && samples.size > 1) {
                val jitterPath = Path()
                var jitterStarted = false
                samples.forEachIndexed { index, sample ->
                    if (sample.isSuccess) {
                        val x = index * stepX
                        val y = yForMs(sample.jitterMs.toFloat())
                        if (!jitterStarted) {
                            jitterPath.moveTo(x, y)
                            jitterStarted = true
                        } else {
                            jitterPath.lineTo(x, y)
                        }
                    }
                }
                if (jitterStarted) {
                    drawPath(
                        path = jitterPath,
                        color = AmberUnstable.copy(alpha = 0.85f),
                        style = Stroke(width = 2.5f, cap = StrokeCap.Round)
                    )
                }
            }

            // Sample dots & failed packet markers
            samples.forEachIndexed { index, sample ->
                val x = if (samples.size == 1) w / 2f else index * stepX
                if (!sample.isSuccess) {
                    val y = padTop + chartH - 8f
                    drawLine(
                        color = CrimsonPoor,
                        start = Offset(x - 6f, y - 6f),
                        end = Offset(x + 6f, y + 6f),
                        strokeWidth = 3f
                    )
                    drawLine(
                        color = CrimsonPoor,
                        start = Offset(x + 6f, y - 6f),
                        end = Offset(x - 6f, y + 6f),
                        strokeWidth = 3f
                    )
                } else if (sample.latencyMs != null && (index == samples.lastIndex || index == selectedIndex)) {
                    val y = yForMs(sample.latencyMs.toFloat())
                    val dotColor = when {
                        sample.latencyMs <= thresholds.excellentMaxMs -> EmeraldExcellent
                        sample.latencyMs <= thresholds.goodMaxMs -> CyberCyan
                        sample.latencyMs <= thresholds.unstableMaxMs -> AmberUnstable
                        else -> CrimsonPoor
                    }
                    drawCircle(
                        color = dotColor.copy(alpha = 0.32f),
                        radius = 14f,
                        center = Offset(x, y)
                    )
                    drawCircle(
                        color = dotColor,
                        radius = 6f,
                        center = Offset(x, y)
                    )
                }
            }

            // Vertical selection indicator
            if (selectedIndex != null && selectedIndex in samples.indices) {
                val x = if (samples.size == 1) w / 2f else selectedIndex * stepX
                drawLine(
                    color = TextPrimary.copy(alpha = 0.45f),
                    start = Offset(x, padTop),
                    end = Offset(x, padTop + chartH),
                    strokeWidth = 2f
                )
            }
        }
    }
}

object FormatUtils {
    private val fullDateFormat = SimpleDateFormat("MMM dd, HH:mm:ss", Locale.getDefault())
    private val timeOnlyFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    fun formatDuration(seconds: Long): String {
        val h = seconds / 3600
        val m = (seconds % 3600) / 60
        val s = seconds % 60
        return if (h > 0) {
            String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
        } else {
            String.format(Locale.US, "%02d:%02d", m, s)
        }
    }

    fun formatDateTime(timestampMs: Long): String =
        fullDateFormat.format(Date(timestampMs))

    fun formatTimeOnly(timestampMs: Long): String =
        timeOnlyFormat.format(Date(timestampMs))
}
