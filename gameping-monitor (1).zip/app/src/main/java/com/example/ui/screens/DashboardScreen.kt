package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ShowChart
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SignalCellularAlt
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.preferences.AppSettings
import com.example.domain.model.ConnectionType
import com.example.domain.model.NetworkMetricsSnapshot
import com.example.ui.components.AnimatedPingChart
import com.example.ui.components.FormatUtils
import com.example.ui.components.MetricTile
import com.example.ui.components.StatusBadgePill
import com.example.ui.components.TacticalCard
import com.example.ui.theme.AmberUnstable
import com.example.ui.theme.BorderSlate
import com.example.ui.theme.CrimsonPoor
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.DeepSlate
import com.example.ui.theme.EmeraldExcellent
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.roundToInt

@Composable
fun DashboardScreen(
    metrics: NetworkMetricsSnapshot,
    settings: AppSettings,
    hasOverlayPermission: Boolean,
    onStartMonitoring: () -> Unit,
    onStopMonitoring: () -> Unit,
    onTogglePause: () -> Unit,
    onToggleOverlay: (Boolean) -> Unit,
    onRequestOverlayPermission: () -> Unit,
    onOpenGraph: () -> Unit,
    onOpenLiveMonitor: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenAbout: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Hero Telemetry Card with generated radar backdrop
            item {
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = DeepSlate,
                    border = BorderStroke(1.dp, metrics.quality.color.copy(alpha = 0.45f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Image(
                            painter = painterResource(id = R.drawable.img_hero_radar),
                            contentDescription = "Tactical radar telemetry backdrop",
                            contentScale = ContentScale.Crop,
                            alpha = 0.28f,
                            modifier = Modifier.matchParentSize()
                        )
                        Box(
                            modifier = Modifier
                                .matchParentSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            ObsidianVoid.copy(alpha = 0.35f),
                                            DeepSlate.copy(alpha = 0.92f)
                                        )
                                    )
                                )
                        )

                        Column(modifier = Modifier.padding(18.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                StatusBadgePill(
                                    quality = metrics.quality,
                                    isMonitoring = metrics.isMonitoring,
                                    isPaused = metrics.isPaused || metrics.isScreenOffPaused
                                )
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = ObsidianVoid.copy(alpha = 0.72f),
                                    border = BorderStroke(1.dp, BorderSlate)
                                ) {
                                    Text(
                                        text = "${metrics.activeMethod.shortBadge} • ${metrics.targetDisplay}",
                                        style = MaterialTheme.typography.labelSmall.copy(color = CyberCyan),
                                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Bottom
                            ) {
                                Column {
                                    Text(
                                        text = "LIVE LATENCY",
                                        style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                                    )
                                    Row(verticalAlignment = Alignment.Bottom) {
                                        val pingValue = when {
                                            !metrics.isMonitoring -> "--"
                                            metrics.livePingMs != null -> metrics.livePingMs.toString()
                                            else -> "--"
                                        }
                                        Text(
                                            text = pingValue,
                                            style = MaterialTheme.typography.displayLarge.copy(
                                                color = if (metrics.isMonitoring && metrics.livePingMs != null) {
                                                    metrics.quality.color
                                                } else {
                                                    TextPrimary
                                                }
                                            )
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "ms",
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontFamily = JetBrainsMonoFontFamily,
                                                color = TextSecondary
                                            ),
                                            modifier = Modifier.padding(bottom = 8.dp)
                                        )
                                    }
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = when (metrics.connectivity.connectionType) {
                                                ConnectionType.WIFI -> Icons.Default.Wifi
                                                else -> Icons.Default.SignalCellularAlt
                                            },
                                            contentDescription = "Connection type",
                                            tint = if (metrics.connectivity.isConnected) EmeraldExcellent else TextMuted,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(5.dp))
                                        Text(
                                            text = metrics.connectivity.transportDetail,
                                            style = MaterialTheme.typography.labelSmall.copy(color = TextPrimary)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "SESSION ${FormatUtils.formatDuration(metrics.sessionDurationSec)}",
                                        style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                                    )
                                }
                            }

                            if (!metrics.lastError.isNullOrBlank()) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = CrimsonPoor.copy(alpha = 0.14f),
                                    border = BorderStroke(1.dp, CrimsonPoor.copy(alpha = 0.4f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = metrics.lastError,
                                        style = MaterialTheme.typography.labelSmall.copy(color = CrimsonPoor),
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Primary Tactical Controls
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                if (!metrics.isMonitoring) {
                                    Button(
                                        onClick = onStartMonitoring,
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                            .testTag("start_monitoring_button"),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = CyberCyan,
                                            contentColor = ObsidianVoid
                                        ),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Start Monitor", fontWeight = FontWeight.Bold)
                                    }
                                } else {
                                    FilledTonalButton(
                                        onClick = onTogglePause,
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                            .testTag("pause_monitoring_button"),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (metrics.isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                                            contentDescription = null
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(if (metrics.isPaused) "Resume" else "Pause")
                                    }

                                    Button(
                                        onClick = onStopMonitoring,
                                        modifier = Modifier
                                            .weight(1f)
                                            .height(48.dp)
                                            .testTag("stop_monitoring_button"),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = CrimsonPoor,
                                            contentColor = Color.White
                                        ),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Icon(Icons.Default.Stop, contentDescription = null)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Stop", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            val overlayActive = settings.overlay.overlayEnabled && hasOverlayPermission
                            OutlinedButton(
                                onClick = {
                                    if (!hasOverlayPermission) {
                                        onRequestOverlayPermission()
                                    } else {
                                        onToggleOverlay(!settings.overlay.overlayEnabled)
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("toggle_overlay_button"),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(
                                    1.dp,
                                    if (overlayActive) EmeraldExcellent else CyberCyan.copy(alpha = 0.6f)
                                )
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Layers,
                                    contentDescription = null,
                                    tint = if (overlayActive) EmeraldExcellent else CyberCyan
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = when {
                                        !hasOverlayPermission -> "Grant Floating Overlay Permission"
                                        overlayActive -> "Floating Game Overlay: ACTIVE (Tap to Hide)"
                                        else -> "Launch Floating Game Overlay"
                                    },
                                    color = if (overlayActive) EmeraldExcellent else CyberCyan,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }

            // 2. Permission Alert Banner if Overlay Permission Missing
            item {
                AnimatedVisibility(visible = !hasOverlayPermission) {
                    TacticalCard(
                        borderColor = AmberUnstable.copy(alpha = 0.5f),
                        containerColor = AmberUnstable.copy(alpha = 0.08f)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.WarningAmber,
                                contentDescription = "Overlay permission required",
                                tint = AmberUnstable
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Overlay Permission Required",
                                    style = MaterialTheme.typography.titleMedium.copy(color = AmberUnstable)
                                )
                                Text(
                                    text = "Enable 'Display over other apps' so the floating ping HUD can stay visible above mobile games.",
                                    style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = onRequestOverlayPermission,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("grant_overlay_permission_banner_btn"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AmberUnstable,
                                contentColor = ObsidianVoid
                            )
                        ) {
                            Text("Open Overlay Settings", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // 3. 4-Metric Telemetry Grid
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricTile(
                            label = "AVG PING",
                            value = if (metrics.totalProbes > 0) "${metrics.avgPingMs}" else "--",
                            unit = "ms",
                            icon = Icons.Default.Speed,
                            accentColor = CyberCyan,
                            modifier = Modifier.weight(1f)
                        )
                        MetricTile(
                            label = "JITTER",
                            value = if (metrics.totalProbes > 1) "${metrics.jitterMs}" else "--",
                            unit = "ms",
                            icon = Icons.Default.Bolt,
                            accentColor = AmberUnstable,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        MetricTile(
                            label = "PACKET LOSS",
                            value = if (metrics.totalProbes > 0) {
                                String.format("%.1f", metrics.packetLossPercent)
                            } else {
                                "0.0"
                            },
                            unit = "%",
                            icon = Icons.Default.WarningAmber,
                            accentColor = if (metrics.packetLossPercent > 0f) CrimsonPoor else EmeraldExcellent,
                            modifier = Modifier.weight(1f)
                        )
                        MetricTile(
                            label = "MIN / MAX",
                            value = if (metrics.minPingMs > 0) {
                                "${metrics.minPingMs}/${metrics.maxPingMs}"
                            } else {
                                "--/--"
                            },
                            unit = "ms",
                            icon = Icons.Default.SwapVert,
                            accentColor = CyberPurple,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // 4. Mini Live Latency Waveform (Tappable to Ping Graph)
            item {
                TacticalCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { onOpenGraph() }
                        .testTag("dashboard_mini_graph_card")
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ShowChart,
                                contentDescription = null,
                                tint = CyberCyan,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Live Ping Waveform",
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                        Text(
                            text = "Full Graph →",
                            style = MaterialTheme.typography.labelMedium.copy(color = CyberCyan)
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    if (metrics.recentSamples.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(110.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Tap 'Start Monitor' to stream live latency samples",
                                style = MaterialTheme.typography.bodyMedium.copy(color = TextMuted)
                            )
                        }
                    } else {
                        AnimatedPingChart(
                            samples = metrics.recentSamples,
                            thresholds = settings.monitoring.thresholds,
                            showJitterOverlay = true,
                            showThresholds = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(125.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Probes: ${metrics.totalProbes} (${metrics.failedProbes} lost)",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                        )
                        Text(
                            text = "DNS: ${metrics.lastDnsMs?.let { "${it} ms" } ?: "--"}",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                        )
                    }
                }
            }

            // 5. Quick Access Modules (Live Monitor, Engine Settings, About)
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "DIAGNOSTICS & TOOLS",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        QuickModuleButton(
                            title = "Live Monitor",
                            subtitle = "ICMP • TCP • HTTPS",
                            icon = Icons.Default.NetworkCheck,
                            accent = EmeraldExcellent,
                            onClick = onOpenLiveMonitor,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("open_live_monitor_card")
                        )
                        QuickModuleButton(
                            title = "Engine Rules",
                            subtitle = "${settings.monitoring.probeIntervalMs}ms • Thresholds",
                            icon = Icons.Default.Tune,
                            accent = CyberCyan,
                            onClick = onOpenSettings,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("open_settings_card")
                        )
                    }
                    QuickModuleButton(
                        title = "About & Technical Methodology",
                        subtitle = "How GamePing measures ping vs. in-game server latency",
                        icon = Icons.Default.Info,
                        accent = CyberPurple,
                        onClick = onOpenAbout,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("open_about_card")
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }
}

@Composable
private fun QuickModuleButton(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = DeepSlate,
        border = BorderStroke(1.dp, BorderSlate)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = accent.copy(alpha = 0.14f),
                modifier = Modifier.size(40.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = accent,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                )
            }
        }
    }
}
