package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.preferences.OverlayPositionPreset
import com.example.data.preferences.OverlaySettings
import com.example.data.preferences.OverlaySize
import com.example.data.preferences.OverlayThemePreset
import com.example.domain.model.NetworkMetricsSnapshot
import com.example.ui.components.TacticalCard
import com.example.ui.theme.AmberUnstable
import com.example.ui.theme.BorderSlate
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DeepSlate
import com.example.ui.theme.EmeraldExcellent
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OverlaySettingsScreen(
    overlay: OverlaySettings,
    metrics: NetworkMetricsSnapshot,
    hasOverlayPermission: Boolean,
    onRequestOverlayPermission: () -> Unit,
    onToggleOverlay: (Boolean) -> Unit,
    onUpdateOverlay: ((OverlaySettings) -> OverlaySettings) -> Unit,
    modifier: Modifier = Modifier
) {
    val bgSwatchColors = listOf(
        0xFF0A0F1D.toInt(),
        0xFF041428.toInt(),
        0xFF170B2B.toInt(),
        0xFF000000.toInt(),
        0xFF111827.toInt()
    )
    val accentSwatchColors = listOf(
        0xFF00FF9D.toInt(),
        0xFF00E5FF.toInt(),
        0xFFA855F7.toInt(),
        0xFFFFB300.toInt(),
        0xFFFF3B5C.toInt()
    )
    val textSwatchColors = listOf(
        0xFFF3F7FF.toInt(),
        0xFFFFFFFF.toInt(),
        0xFF00E5FF.toInt(),
        0xFF00FF9D.toInt(),
        0xFFE2E8F0.toInt()
    )

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Live Interactive Preview Card
            item {
                TacticalCard(borderColor = CyberCyan.copy(alpha = 0.4f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("LIVE OVERLAY PREVIEW", style = MaterialTheme.typography.labelSmall.copy(color = CyberCyan))
                        Text(
                            text = if (overlay.expandedByDefault) "Expanded Mode" else "Compact Mode",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                        )
                    }
                    Spacer(modifier = Modifier.height(14.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF05070D))
                            .padding(vertical = 22.dp, horizontal = 14.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        OverlayPreviewWidget(overlay = overlay, metrics = metrics)
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Enable Floating Overlay", style = MaterialTheme.typography.titleMedium)
                            Text(
                                text = if (hasOverlayPermission) {
                                    "Stays visible above supported games and apps"
                                } else {
                                    "Requires 'Display over other apps' permission"
                                },
                                style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary)
                            )
                        }
                        if (hasOverlayPermission) {
                            Switch(
                                checked = overlay.overlayEnabled,
                                onCheckedChange = onToggleOverlay,
                                modifier = Modifier.testTag("overlay_enable_switch")
                            )
                        } else {
                            Button(
                                onClick = onRequestOverlayPermission,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = AmberUnstable,
                                    contentColor = ObsidianVoid
                                ),
                                modifier = Modifier.testTag("overlay_grant_permission_btn")
                            ) {
                                Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Allow", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // 2. Gaming Theme Presets + Custom Colors
            item {
                TacticalCard {
                    Text("Overlay Theme", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(10.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OverlayThemePreset.entries.forEach { preset ->
                            FilterChip(
                                selected = overlay.themePreset == preset,
                                onClick = {
                                    onUpdateOverlay { it.copy(themePreset = preset) }
                                },
                                label = { Text(preset.displayName) },
                                modifier = Modifier.testTag("theme_chip_${preset.name.lowercase()}")
                            )
                        }
                    }

                    if (overlay.themePreset == OverlayThemePreset.CUSTOM) {
                        Spacer(modifier = Modifier.height(12.dp))
                        ColorSwatchRow(
                            title = "Background Color",
                            colors = bgSwatchColors,
                            selected = overlay.customBgColorArgb,
                            onSelect = { color ->
                                onUpdateOverlay { it.copy(customBgColorArgb = color) }
                            }
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        ColorSwatchRow(
                            title = "Border & Accent Color",
                            colors = accentSwatchColors,
                            selected = overlay.customAccentColorArgb,
                            onSelect = { color ->
                                onUpdateOverlay { it.copy(customAccentColorArgb = color) }
                            }
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        ColorSwatchRow(
                            title = "Text Color",
                            colors = textSwatchColors,
                            selected = overlay.customTextColorArgb,
                            onSelect = { color ->
                                onUpdateOverlay { it.copy(customTextColorArgb = color) }
                            }
                        )
                    }
                }
            }

            // 3. Size, Transparency & Font Size
            item {
                TacticalCard {
                    Text("Dimensions & Transparency", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(10.dp))

                    Text("Widget Size", style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary))
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OverlaySize.entries.forEach { size ->
                            FilterChip(
                                selected = overlay.size == size,
                                onClick = {
                                    onUpdateOverlay { it.copy(size = size, fontSizeSp = size.baseFontSp) }
                                },
                                label = { Text(size.label) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Transparency", style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary))
                        Text(
                            text = "${(overlay.alpha * 100).roundToInt()}%",
                            style = MaterialTheme.typography.labelMedium.copy(color = CyberCyan)
                        )
                    }
                    Slider(
                        value = overlay.alpha,
                        onValueChange = { value ->
                            onUpdateOverlay { it.copy(alpha = value) }
                        },
                        valueRange = 0.30f..1.0f,
                        colors = SliderDefaults.colors(thumbColor = CyberCyan, activeTrackColor = CyberCyan),
                        modifier = Modifier.testTag("overlay_alpha_slider")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Font Size", style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary))
                        Text(
                            text = "${String.format("%.1f", overlay.fontSizeSp)} sp",
                            style = MaterialTheme.typography.labelMedium.copy(color = CyberCyan)
                        )
                    }
                    Slider(
                        value = overlay.fontSizeSp,
                        onValueChange = { value ->
                            onUpdateOverlay { it.copy(fontSizeSp = value) }
                        },
                        valueRange = 9.5f..18f,
                        colors = SliderDefaults.colors(thumbColor = CyberCyan, activeTrackColor = CyberCyan),
                        modifier = Modifier.testTag("overlay_font_slider")
                    )
                }
            }

            // 4. Position & Layout Mode
            item {
                TacticalCard {
                    Text("Position & Behavior", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(10.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OverlayPositionPreset.entries.forEach { pos ->
                            FilterChip(
                                selected = overlay.positionPreset == pos,
                                onClick = {
                                    onUpdateOverlay { it.copy(positionPreset = pos) }
                                },
                                label = { Text(pos.label) }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    SwitchSettingRow(
                        title = "Start in Expanded Layout",
                        subtitle = "Show full stats (Avg/Min/Max & quick buttons) by default",
                        checked = overlay.expandedByDefault,
                        onCheckedChange = { v -> onUpdateOverlay { it.copy(expandedByDefault = v) } }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    SwitchSettingRow(
                        title = "Lock Touch Pass-Through",
                        subtitle = "Prevent accidental drags during gameplay (touches pass straight through to game)",
                        checked = overlay.lockTouchThrough,
                        onCheckedChange = { v -> onUpdateOverlay { it.copy(lockTouchThrough = v) } }
                    )
                }
            }

            // 5. Visible Telemetry Metrics
            item {
                TacticalCard {
                    Text("Displayed Overlay Metrics", style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    SwitchSettingRow(
                        title = "Show Jitter (ms)",
                        subtitle = "Display latency variance stability",
                        checked = overlay.showJitter,
                        onCheckedChange = { v -> onUpdateOverlay { it.copy(showJitter = v) } }
                    )
                    SwitchSettingRow(
                        title = "Show Packet Loss (%)",
                        subtitle = "Display dropped probe percentage",
                        checked = overlay.showPacketLoss,
                        onCheckedChange = { v -> onUpdateOverlay { it.copy(showPacketLoss = v) } }
                    )
                    SwitchSettingRow(
                        title = "Show Avg / Min / Max",
                        subtitle = "Visible in expanded HUD mode",
                        checked = overlay.showAvgMinMax,
                        onCheckedChange = { v -> onUpdateOverlay { it.copy(showAvgMinMax = v) } }
                    )
                    SwitchSettingRow(
                        title = "Show Connection Type",
                        subtitle = "Wi-Fi / Mobile / VPN indicator",
                        checked = overlay.showConnectionType,
                        onCheckedChange = { v -> onUpdateOverlay { it.copy(showConnectionType = v) } }
                    )
                    SwitchSettingRow(
                        title = "Show Probe Method Badge",
                        subtitle = "Distinguish TCP, ICMP, HTTPS, or DNS",
                        checked = overlay.showProbeMethod,
                        onCheckedChange = { v -> onUpdateOverlay { it.copy(showProbeMethod = v) } }
                    )
                }
            }

            item { Spacer(modifier = Modifier.height(12.dp)) }
        }
    }
}

@Composable
private fun OverlayPreviewWidget(
    overlay: OverlaySettings,
    metrics: NetworkMetricsSnapshot
) {
    val bg = Color(overlay.effectiveBgColor()).copy(alpha = overlay.alpha)
    val border = Color(overlay.effectiveBorderColor())
    val text = Color(overlay.effectiveTextColor())
    val accent = Color(overlay.effectiveAccentColor())
    val qualityColor = metrics.quality.color
    val pingStr = metrics.livePingMs?.let { "$it ms" } ?: "32 ms"
    val fontSize = (overlay.fontSizeSp * overlay.size.scale).sp

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = bg,
        border = BorderStroke(1.2.dp, border)
    ) {
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(9.dp)
                        .clip(CircleShape)
                        .background(qualityColor)
                )
                Spacer(modifier = Modifier.width(7.dp))
                Text(
                    text = pingStr,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontFamily = JetBrainsMonoFontFamily,
                        fontSize = fontSize * 1.1f,
                        color = qualityColor,
                        fontWeight = FontWeight.Bold
                    )
                )
                if (overlay.showProbeMethod) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = accent.copy(alpha = 0.16f),
                        border = BorderStroke(0.8.dp, accent.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = metrics.activeMethod.shortBadge,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = fontSize * 0.72f,
                                color = accent
                            ),
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                        )
                    }
                }
                if (!overlay.expandedByDefault) {
                    val parts = buildList {
                        if (overlay.showJitter) add("J:${metrics.jitterMs}ms")
                        if (overlay.showPacketLoss) add("L:${metrics.packetLossPercent.roundToInt()}%")
                        if (overlay.showConnectionType) add(metrics.connectivity.connectionType.shortLabel)
                    }
                    if (parts.isNotEmpty()) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = parts.joinToString(" • "),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = fontSize * 0.82f,
                                color = text
                            )
                        )
                    }
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (overlay.expandedByDefault) "▴" else "▾",
                    color = accent,
                    fontSize = fontSize
                )
            }

            if (overlay.expandedByDefault) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "NETWORK: ${metrics.quality.shortStatus}",
                    style = MaterialTheme.typography.labelSmall.copy(color = qualityColor, fontSize = fontSize * 0.82f)
                )
                if (overlay.showJitter || overlay.showPacketLoss) {
                    Text(
                        text = "JITTER: ${metrics.jitterMs} ms   LOSS: ${String.format("%.1f", metrics.packetLossPercent)}%",
                        style = MaterialTheme.typography.labelSmall.copy(color = text, fontSize = fontSize * 0.82f)
                    )
                }
                if (overlay.showAvgMinMax) {
                    Text(
                        text = "AVG ${metrics.avgPingMs}  MIN ${metrics.minPingMs}  MAX ${metrics.maxPingMs} ms",
                        style = MaterialTheme.typography.labelSmall.copy(color = text, fontSize = fontSize * 0.82f)
                    )
                }
                if (overlay.showConnectionType) {
                    Text(
                        text = "CONN: ${metrics.connectivity.transportDetail}",
                        style = MaterialTheme.typography.labelSmall.copy(color = text, fontSize = fontSize * 0.82f)
                    )
                }
            }
        }
    }
}

@Composable
private fun ColorSwatchRow(
    title: String,
    colors: List<Int>,
    selected: Int,
    onSelect: (Int) -> Unit
) {
    Column {
        Text(text = title, style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary))
        Spacer(modifier = Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            colors.forEach { argb ->
                val isSelected = argb == selected
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(argb))
                        .border(
                            width = if (isSelected) 3.dp else 1.dp,
                            color = if (isSelected) CyberCyan else BorderSlate,
                            shape = CircleShape
                        )
                        .clickable { onSelect(argb) }
                )
            }
        }
    }
}

@Composable
fun SwitchSettingRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(text = title, style = MaterialTheme.typography.bodyLarge.copy(color = TextPrimary))
            Text(text = subtitle, style = MaterialTheme.typography.bodyMedium.copy(color = TextSecondary))
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange
        )
    }
}
