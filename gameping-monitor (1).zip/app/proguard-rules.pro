# Add project specific ProGuard rules here.
# Preserve line numbers for readable crash reports
-keepattributes SourceFile,LineNumberTable

# Kotlinx Serialization (used for Navigation Compose @Serializable routes)
-keepattributes *Annotation*,InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class kotlinx.serialization.json.** { kotlinx.serialization.KSerializer serializer(...); }
-keep,includedescriptorclasses class com.example.ui.navigation.**$$serializer { *; }
-keepclassmembers class com.example.ui.navigation.** { *** Companion; }
-keepclasseswithmembers class com.example.ui.navigation.** { kotlinx.serialization.KSerializer serializer(...); }

# Room database entities, DAOs, and generated database implementation
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-keepclassmembers class com.example.data.local.** { *; }

# Keep Foreground Service & Application classes
-keep class com.example.GamePingApplication { *; }
-keep class com.example.service.NetworkMonitorService { *; }

# OkHttp optional platform warnings
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
