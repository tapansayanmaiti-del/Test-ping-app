# GamePing Monitor — APK Packaging & Delivery Plan

Prepare an installable, release-ready Android APK package for **GamePing Monitor** and provide clear delivery paths through Google AI Studio's APK generator and local Gradle builds, since binary `.apk` files cannot be transmitted directly inside chat messages.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> Chat responses cannot attach or stream binary `.apk` files directly. The compiled debug package (`app-debug.apk`) is already built in the project workspace and can be downloaded via **Google AI Studio → Settings / Export → Generate APK / AAB**.

- **Recommended Default (APK Build Readiness & Verification)**: Verify release/debug signing compatibility, ProGuard rules (preserving Room, Kotlin Serialization, OkHttp, and Service reflection targets), and APK size optimization so the generated APK installs cleanly on Android 10–16 devices.
- **Alternative Choice (In-App Diagnostic Export)**: Optionally add a one-tap CSV/JSON telemetry export button in Network History if you want to share session logs externally alongside the APK.

---

## 1. Overview & Core Concept

- **What It Does**: Ensures **GamePing Monitor** compiles cleanly into both an installable Debug APK (for immediate sideloading) and a properly configured Release APK/AAB (for distribution), while surfacing clear build/install guidance inside the About screen.
- **Target Audience**: Mobile gamers and Android testers who want to sideload the app on physical devices to test the floating `WindowManager` ping overlay over real games.
- **Key Value**: Eliminates packaging issues (such as missing ProGuard keep rules for serialization/Room or oversized unused dependencies) before downloading the APK from AI Studio.

---

## 2. User Experience & Visual Design

- **AI Studio Download Flow**:
  1. Open the **Settings / Export** menu in Google AI Studio.
  2. Choose **Generate APK / AAB** to download the packaged `.apk` directly to your computer or phone.
  3. On Android, open the downloaded file (allowing *Install unknown apps* if prompted), launch **GamePing Monitor**, and grant **Display over other apps** permission.
- **In-App Packaging & Sideload Guide (About Screen)**:
  - Keep the existing **Obsidian Void (`#070B14`)** and **Cyber Cyan (`#00E5FF`)** dark tactical Material 3 theme with **Space Grotesk** headings and **JetBrains Mono** code/telemetry badges.
  - Enhance the **Device Testing & Verification** card in the About view with concise sideloading and permission verification steps for physical devices.

---

## 3. Key Product Decisions & Trade-Offs

- **Delivery via AI Studio Export vs. Chat Attachment**:
  - *Chosen Approach*: Direct users to AI Studio's built-in **Generate APK / AAB** action while ensuring the Gradle build outputs an up-to-date, verified APK.
  - *Why*: The chat interface only supports text responses and cannot host binary `.apk` downloads.
  - *Alternatives Considered*: Exporting source ZIP / GitHub repo and building locally via `gradle :app:assembleDebug` (also supported as a fallback).
- **ProGuard / R8 Keep Rules Verification**:
  - *Chosen Approach*: Audit and update ProGuard configuration for `kotlinx.serialization`, Room entities, and OkHttp without modifying AI Studio's managed `signingConfigs`.
  - *Why*: Ensures release builds generated via **Generate APK / AAB** do not strip `@Serializable` navigation route classes or Room metadata.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

```text
┌────────────────────────────────────────────────────────────────┐
│                  Google AI Studio Build Pipeline               │
│                                                                │
│  ┌──────────────────────┐        ┌──────────────────────────┐  │
│  │  Kotlin / Compose    │        │  Gradle Packaging Layer  │  │
│  │  App + Overlay + FGS ├───────►│  • Debug APK (assemble)  │  │
│  └──────────────────────┘        │  • Release APK / AAB     │  │
│                                  │  • ProGuard Keep Rules   │  │
│                                  └────────────┬─────────────┘  │
└───────────────────────────────────────────────┼────────────────┘
                                                ▼
                                ┌────────────────────────────────┐
                                │  AI Studio Export / Settings   │
                                │  "Generate APK / AAB" Download │
                                └───────────────┬────────────────┘
                                                ▼
                                ┌────────────────────────────────┐
                                │   Physical Android Device      │
                                │   Sideload → Grant Overlay →   │
                                │   Run Over Live Games          │
                                └────────────────────────────────┘
```

- **State & Configuration Safety**: Existing DataStore preferences, Room history schema, `NetworkMonitorService`, and `FloatingOverlayManager` remain untouched, and AI Studio's `signingConfigs` (`debugConfig` and `release`) are preserved intact.
- **Verification Plan**: Run `compile_applet`, `gradle :app:assembleDebug`, and `gradle :app:testDebugUnitTest` after confirming any ProGuard or About-screen guidance updates.
